import React, { createContext, useContext, useEffect, useReducer, useState } from 'react'
import {
  loadState,
  saveState,
  flushSave,
  resetSeeds,
  onQuotaExceeded,
  writeShadowBackup,
  getLoadReport,
  TRASH_LIMIT,
  PRACTICE_LOG_LIMIT,
} from '../storage/store.js'
import { pruneOrphans } from '../storage/audio.js'
import { newId } from '../utils/id.js'

const AppContext = createContext(null)

// Which collection each trash entry belongs to.
const COLLECTION = {
  question: 'questions',
  opener: 'openers',
  rescue: 'rescues',
  story: 'stories',
  person: 'people',
}

function pushTrash(state, entry) {
  return [{ ...entry, deletedAt: new Date().toISOString() }, ...state.trash].slice(0, TRASH_LIMIT)
}

// Seeds are soft-deleted (kept so "restore built-in" can bring them back);
// user items are removed outright. Either way the item lands in the trash.
function deleteFrom(state, kind, id) {
  const key = COLLECTION[kind]
  const list = state[key]
  const index = list.findIndex((x) => x.id === id)
  if (index === -1) return state
  const item = list[index]
  const isSeed = item.source === 'seed'
  return {
    ...state,
    [key]: isSeed
      ? list.map((x) => (x.id === id ? { ...x, deleted: true } : x))
      : list.filter((x) => x.id !== id),
    trash: pushTrash(state, { kind, item, index, wasSeed: isSeed }),
  }
}

function restoreFromTrash(state, deletedAt) {
  const entry = state.trash.find((t) => t.deletedAt === deletedAt)
  if (!entry) return state
  const key = COLLECTION[entry.kind]
  const list = state[key]
  let next
  if (entry.wasSeed) {
    next = list.map((x) => (x.id === entry.item.id ? { ...x, deleted: false } : x))
    // Seed row could have been dropped by an import — re-add it if so.
    if (!list.some((x) => x.id === entry.item.id)) next = [...list, { ...entry.item, deleted: false }]
  } else {
    next = [...list]
    next.splice(Math.min(entry.index, next.length), 0, entry.item)
  }
  return { ...state, [key]: next, trash: state.trash.filter((t) => t.deletedAt !== deletedAt) }
}

function reducer(state, action) {
  switch (action.type) {
    case 'ADD_QUESTION':
      return {
        ...state,
        questions: [
          { id: newId(), text: action.text, category: action.category, tags: [], favorite: false, source: 'user', deleted: false },
          ...state.questions,
        ],
      }
    case 'EDIT_QUESTION':
      return {
        ...state,
        questions: state.questions.map((q) =>
          q.id === action.id ? { ...q, text: action.text, category: action.category } : q
        ),
      }
    case 'TOGGLE_FAVORITE_QUESTION':
      return {
        ...state,
        questions: state.questions.map((q) => (q.id === action.id ? { ...q, favorite: !q.favorite } : q)),
      }

    case 'ADD_OPENER':
      return {
        ...state,
        openers: [
          { id: newId(), text: action.text, situation: action.situation, favorite: false, source: 'user', deleted: false },
          ...state.openers,
        ],
      }
    case 'EDIT_OPENER':
      return {
        ...state,
        openers: state.openers.map((o) =>
          o.id === action.id ? { ...o, text: action.text, situation: action.situation } : o
        ),
      }
    case 'TOGGLE_FAVORITE_OPENER':
      return {
        ...state,
        openers: state.openers.map((o) => (o.id === action.id ? { ...o, favorite: !o.favorite } : o)),
      }

    case 'ADD_RESCUE':
      return {
        ...state,
        rescues: [
          { id: newId(), text: action.text, situation: action.situation, favorite: false, source: 'user', deleted: false },
          ...state.rescues,
        ],
      }
    case 'EDIT_RESCUE':
      return {
        ...state,
        rescues: state.rescues.map((x) =>
          x.id === action.id ? { ...x, text: action.text, situation: action.situation } : x
        ),
      }
    case 'TOGGLE_FAVORITE_RESCUE':
      return {
        ...state,
        rescues: state.rescues.map((x) => (x.id === action.id ? { ...x, favorite: !x.favorite } : x)),
      }

    case 'ADD_PERSON': {
      const now = new Date().toISOString()
      return {
        ...state,
        people: [
          { id: newId(), name: action.name, notes: action.notes ?? '', createdAt: now, updatedAt: now },
          ...state.people,
        ],
      }
    }
    case 'EDIT_PERSON':
      return {
        ...state,
        people: state.people.map((p) =>
          p.id === action.id
            ? { ...p, name: action.name, notes: action.notes, updatedAt: new Date().toISOString() }
            : p
        ),
      }

    case 'DELETE_ITEM':
      return deleteFrom(state, action.kind, action.id)
    case 'RESTORE_TRASH':
      return restoreFromTrash(state, action.deletedAt)
    case 'CLEAR_TRASH':
      return { ...state, trash: [] }

    case 'CREATE_STORY': {
      const now = new Date().toISOString()
      return {
        ...state,
        stories: [
          { id: action.id, title: '', fullText: '', beats: [], tags: [], practiceCount: 0, createdAt: now, updatedAt: now },
          ...state.stories,
        ],
      }
    }
    case 'UPDATE_STORY':
      return {
        ...state,
        stories: state.stories.map((s) =>
          s.id === action.id ? { ...s, ...action.patch, updatedAt: new Date().toISOString() } : s
        ),
      }
    case 'DISCARD_EMPTY_STORY':
      // Never trashed — an untouched draft is not something anyone wants back.
      return { ...state, stories: state.stories.filter((s) => s.id !== action.id) }

    case 'INCREMENT_PRACTICE':
      return {
        ...state,
        stories: state.stories.map((s) =>
          s.id === action.id ? { ...s, practiceCount: s.practiceCount + 1 } : s
        ),
        practiceLog: [{ storyId: action.id, at: new Date().toISOString() }, ...state.practiceLog].slice(
          0,
          PRACTICE_LOG_LIMIT
        ),
      }

    // "I actually used this" — turns favourites into evidence rather than intention.
    case 'MARK_USED': {
      const key = COLLECTION[action.kind]
      return {
        ...state,
        [key]: state[key].map((x) =>
          x.id === action.id
            ? { ...x, usedCount: (x.usedCount ?? 0) + 1, lastUsedAt: new Date().toISOString() }
            : x
        ),
      }
    }

    case 'ADD_RECORDING':
      return {
        ...state,
        stories: state.stories.map((s) =>
          s.id === action.storyId ? { ...s, recordings: [action.recording, ...(s.recordings ?? [])] } : s
        ),
      }
    case 'DELETE_RECORDING':
      return {
        ...state,
        stories: state.stories.map((s) =>
          s.id === action.storyId
            ? { ...s, recordings: (s.recordings ?? []).filter((r) => r.id !== action.recordingId) }
            : s
        ),
      }

    case 'RESET_SEEDS':
      return resetSeeds(state)
    case 'IMPORT_STATE':
      return action.state
    case 'MARK_BACKED_UP':
      return { ...state, settings: { ...state.settings, lastBackupAt: new Date().toISOString() } }
    case 'SET_THEME':
      return { ...state, settings: { ...state.settings, theme: action.theme } }
    case 'SET_SETTING':
      return { ...state, settings: { ...state.settings, [action.key]: action.value } }
    default:
      return state
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadState)
  const [storageError, setStorageError] = useState(null)
  const [loadReport] = useState(getLoadReport)
  const [undo, setUndo] = useState(null)
  // App-wide UI state (not persisted): the privacy veil any screen can raise.
  const [veiled, setVeiled] = useState(false)

  useEffect(() => {
    onQuotaExceeded(() => setStorageError('Storage is full — export a backup, then delete some items.'))
  }, [])

  useEffect(() => {
    saveState(state)
  }, [state])

  // Phones background apps without warning — flush the main doc AND refresh the
  // shadow copy at that moment, so the backup is never more than one session stale.
  // Same moment is when we raise the veil, so the app-switcher snapshot is blank.
  useEffect(() => {
    const flush = () => {
      if (document.visibilityState === 'hidden') {
        flushSave(state)
        writeShadowBackup(state)
        if (state.settings.veilOnSwitch) setVeiled(true)
      }
    }
    document.addEventListener('visibilitychange', flush)
    window.addEventListener('pagehide', flush)
    return () => {
      document.removeEventListener('visibilitychange', flush)
      window.removeEventListener('pagehide', flush)
    }
  }, [state])

  // Seed the shadow copy on first run so recovery works even before a backgrounding.
  useEffect(() => {
    writeShadowBackup(state)
    // Drop audio blobs no story (or trashed story) references any more. Trash is
    // included so an undo still has its recordings to come back to.
    const live = state.stories.flatMap((s) => (s.recordings ?? []).map((r) => r.id))
    const trashed = state.trash
      .filter((t) => t.kind === 'story')
      .flatMap((t) => (t.item.recordings ?? []).map((r) => r.id))
    pruneOrphans([...live, ...trashed]).catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Delete with an undo window. The item is in the trash either way — this just
  // surfaces the one-tap path back.
  const deleteItem = (kind, id, label) => {
    dispatch({ type: 'DELETE_ITEM', kind, id })
    setUndo({ label, at: Date.now() })
  }

  const markUsed = (kind, id) => dispatch({ type: 'MARK_USED', kind, id })

  const undoLastDelete = () => {
    if (state.trash.length > 0) dispatch({ type: 'RESTORE_TRASH', deletedAt: state.trash[0].deletedAt })
    setUndo(null)
  }

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        storageError,
        setStorageError,
        loadReport,
        undo,
        setUndo,
        deleteItem,
        undoLastDelete,
        markUsed,
        veiled,
        setVeiled,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  return useContext(AppContext)
}
