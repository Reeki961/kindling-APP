import { useEffect, useRef, useState } from 'react'
import { putRecording, isAudioSupported } from '../storage/audio.js'
import { newId } from '../utils/id.js'

// Pick a container the browser will actually produce. Safari only does mp4.
function pickMimeType() {
  const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus']
  for (const t of candidates) {
    if (MediaRecorder.isTypeSupported?.(t)) return t
  }
  return ''
}

const fmt = (ms) => {
  const s = Math.floor(ms / 1000)
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

export default function Recorder({ onSaved, compact = false }) {
  const [recording, setRecording] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [error, setError] = useState(null)
  const recorderRef = useRef(null)
  const chunksRef = useRef([])
  const streamRef = useRef(null)
  const startedAtRef = useRef(0)
  const timerRef = useRef(null)

  const stopTracks = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop())
    streamRef.current = null
  }

  // Never leave the mic open if the screen unmounts mid-recording.
  useEffect(() => {
    return () => {
      if (recorderRef.current?.state === 'recording') recorderRef.current.stop()
      clearInterval(timerRef.current)
      stopTracks()
    }
  }, [])

  const start = async () => {
    setError(null)
    if (!isAudioSupported()) {
      setError('This browser cannot record audio.')
      return
    }
    let stream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch (e) {
      setError(
        e?.name === 'NotAllowedError'
          ? 'Microphone access was blocked. Allow it in your browser settings to record.'
          : 'Could not reach a microphone.'
      )
      return
    }
    streamRef.current = stream
    const mimeType = pickMimeType()
    let rec
    try {
      rec = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
    } catch {
      stopTracks()
      setError('This browser cannot record in a supported format.')
      return
    }
    chunksRef.current = []
    rec.ondataavailable = (e) => {
      if (e.data.size > 0) chunksRef.current.push(e.data)
    }
    rec.onstop = async () => {
      clearInterval(timerRef.current)
      const durationMs = Date.now() - startedAtRef.current
      const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' })
      stopTracks()
      setRecording(false)
      setElapsed(0)
      if (blob.size === 0) {
        setError('Nothing was captured.')
        return
      }
      const id = newId()
      const ok = await putRecording(id, blob)
      if (!ok) {
        setError('Could not save the recording — storage may be full.')
        return
      }
      onSaved({ id, createdAt: new Date().toISOString(), durationMs, mimeType: blob.type, size: blob.size })
    }
    recorderRef.current = rec
    startedAtRef.current = Date.now()
    rec.start()
    setRecording(true)
    timerRef.current = setInterval(() => setElapsed(Date.now() - startedAtRef.current), 200)
  }

  const stop = () => {
    if (recorderRef.current?.state === 'recording') recorderRef.current.stop()
  }

  return (
    <div className={compact ? 'recorder compact' : 'recorder'}>
      <button
        className={`btn ${recording ? 'btn-recording' : 'btn-ghost'}`}
        onClick={recording ? stop : start}
        aria-label={recording ? 'Stop recording' : 'Start recording'}
      >
        {recording ? `■ Stop · ${fmt(elapsed)}` : '● Record yourself telling it'}
      </button>
      {error && <p className="settings-note recorder-error">{error}</p>}
    </div>
  )
}
