const DAY = 24 * 60 * 60 * 1000

// Local-midnight day index, so streaks follow the user's calendar days
// rather than UTC boundaries.
function dayIndex(d) {
  const dt = new Date(d)
  return Math.floor(new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()).getTime() / DAY)
}

export function practiceStats(practiceLog = []) {
  // days is always 7 long so the strip renders its empty boxes rather than vanishing.
  if (practiceLog.length === 0) {
    return { current: 0, longest: 0, thisWeek: 0, total: 0, days: Array(7).fill(false) }
  }

  const indices = [...new Set(practiceLog.map((e) => dayIndex(e.at)))].sort((a, b) => a - b)
  const today = dayIndex(Date.now())

  // Longest run of consecutive days, ever.
  let longest = 1
  let run = 1
  for (let i = 1; i < indices.length; i++) {
    run = indices[i] === indices[i - 1] + 1 ? run + 1 : 1
    if (run > longest) longest = run
  }

  // Current streak counts back from today — or yesterday, so a day still in
  // progress doesn't read as a broken streak.
  const last = indices[indices.length - 1]
  let current = 0
  if (last === today || last === today - 1) {
    current = 1
    for (let i = indices.length - 1; i > 0; i--) {
      if (indices[i] === indices[i - 1] + 1) current++
      else break
    }
  }

  const weekAgo = Date.now() - 7 * DAY
  const thisWeek = practiceLog.filter((e) => new Date(e.at).getTime() >= weekAgo).length

  // Last 7 calendar days as booleans, oldest first — for the dot strip.
  const recent = new Set(indices)
  const days = Array.from({ length: 7 }, (_, i) => recent.has(today - (6 - i)))

  return { current, longest, thisWeek, total: practiceLog.length, days }
}
