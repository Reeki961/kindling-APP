export default function ListItem({ text, subLabel, favorite, onToggleFavorite, onEdit }) {
  return (
    <div className="item">
      <div className="item-text">
        {text}
        {subLabel && <span className="item-cat">{subLabel}</span>}
      </div>
      <div className="item-actions">
        <button
          className={`icon-btn ${favorite ? 'fav' : ''}`}
          onClick={onToggleFavorite}
          aria-label={favorite ? 'Unfavorite' : 'Favorite'}
        >
          {favorite ? '★' : '☆'}
        </button>
        <button className="icon-btn" onClick={onEdit} aria-label="Edit">
          ✎
        </button>
      </div>
    </div>
  )
}
