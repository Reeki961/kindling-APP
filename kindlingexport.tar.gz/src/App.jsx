import { useEffect, useState } from 'react'
import { useApp } from './context/AppContext.jsx'
import { DEFAULT_THEME } from './data/themes.js'
import Ambient from './components/Ambient.jsx'
import TabBar from './components/TabBar.jsx'
import NavBar from './components/NavBar.jsx'
import UndoToast from './components/UndoToast.jsx'
import PrivacyVeil from './components/PrivacyVeil.jsx'
import ShareCatcher from './components/ShareCatcher.jsx'
import QuestionsView from './views/QuestionsView.jsx'
import OpenersView from './views/OpenersView.jsx'
import RescueView from './views/RescueView.jsx'
import PeopleView from './views/PeopleView.jsx'
import StoriesView from './views/StoriesView.jsx'
import SettingsView from './views/SettingsView.jsx'

const DAYS_30 = 30 * 24 * 60 * 60 * 1000

const TAB_TITLES = {
  questions: 'Questions',
  openers: 'Openers',
  rescue: 'Rescue',
  people: 'People',
  stories: 'Stories',
  settings: 'Settings',
}

export default function App() {
  const { state, storageError, setStorageError, loadReport, undo, setUndo, undoLastDelete, veiled, setVeiled } =
    useApp()
  const [tab, setTab] = useState('questions')
  const [backupNudgeDismissed, setBackupNudgeDismissed] = useState(false)
  const [recoveryDismissed, setRecoveryDismissed] = useState(false)

  // Text arriving from the OS share sheet. Read once, then scrub the URL so a
  // reload doesn't re-offer the same item.
  const [shared, setShared] = useState(() => {
    const params = new URLSearchParams(window.location.search)
    const parts = [params.get('title'), params.get('text'), params.get('url')].filter(Boolean)
    return parts.length > 0 ? parts.join(' ').trim() : null
  })
  useEffect(() => {
    if (window.location.search || window.location.pathname !== '/') {
      window.history.replaceState({}, '', '/')
    }
  }, [])

  const theme = state.settings.theme ?? DEFAULT_THEME
  useEffect(() => {
    document.documentElement.dataset.theme = theme
  }, [theme])

  // Discreet mode shrinks and dims the text so it's only legible up close.
  const discreet = state.settings.discreet ?? false
  useEffect(() => {
    document.documentElement.dataset.discreet = discreet ? 'true' : 'false'
  }, [discreet])


  // Ask the browser to protect our storage once the user has real data of their own.
  const hasUserData =
    state.stories.length > 0 || state.questions.filter((q) => q.source === 'user').length >= 5
  useEffect(() => {
    if (hasUserData && navigator.storage?.persist) navigator.storage.persist().catch(() => {})
  }, [hasUserData])

  const backupStale =
    hasUserData &&
    (!state.settings.lastBackupAt || Date.now() - new Date(state.settings.lastBackupAt).getTime() > DAYS_30)

  return (
    <div className="app">
      <Ambient />

      {!loadReport.storageAvailable && (
        <div className="banner error" style={{ margin: '12px 16px 0' }}>
          <span>
            This browser isn't letting Kindling save anything — private browsing, most likely. Nothing you add here
            will survive a reload.
          </span>
        </div>
      )}

      {loadReport.recovered && !recoveryDismissed && (
        <div className="banner" style={{ margin: '12px 16px 0' }}>
          <span>Your main data was unreadable, so Kindling restored it from its own backup copy.</span>
          <button onClick={() => setRecoveryDismissed(true)}>✕</button>
        </div>
      )}

      {loadReport.wipedCorrupt && !loadReport.recovered && !recoveryDismissed && (
        <div className="banner error" style={{ margin: '12px 16px 0' }}>
          <span>
            Kindling couldn't read your saved data or its backup copy, so it started fresh. If you have an exported
            file, import it from Settings.
          </span>
          <button onClick={() => setRecoveryDismissed(true)}>✕</button>
        </div>
      )}

      {storageError && (
        <div className="banner error" style={{ margin: '12px 16px 0' }}>
          <span>{storageError}</span>
          <button onClick={() => setStorageError(null)}>✕</button>
        </div>
      )}

      {backupStale && !backupNudgeDismissed && tab !== 'settings' && (
        <div className="banner" style={{ margin: '12px 16px 0' }}>
          <span>You have your own stuff in here now — worth exporting a backup.</span>
          <span style={{ display: 'flex', gap: 12 }}>
            <button onClick={() => setTab('settings')}>Go</button>
            <button onClick={() => setBackupNudgeDismissed(true)}>✕</button>
          </span>
        </div>
      )}

      <NavBar title={TAB_TITLES[tab]} />

      {tab === 'questions' && <QuestionsView />}
      {tab === 'openers' && <OpenersView />}
      {tab === 'rescue' && <RescueView />}
      {tab === 'people' && <PeopleView />}
      {tab === 'stories' && <StoriesView />}
      {tab === 'settings' && <SettingsView />}

      {shared && <ShareCatcher shared={shared} onClose={() => setShared(null)} />}

      {undo && (
        <UndoToast
          key={undo.at}
          label={undo.label}
          onUndo={undoLastDelete}
          onDismiss={() => setUndo(null)}
        />
      )}

      <TabBar tab={tab} onChange={setTab} />

      {veiled && <PrivacyVeil onDismiss={() => setVeiled(false)} />}
    </div>
  )
}
