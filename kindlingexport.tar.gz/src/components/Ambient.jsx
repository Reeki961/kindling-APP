// Drifting colour field behind the glass. Pure decoration — transform-animated
// (GPU) rather than animating gradients, so it stays smooth on a phone.
export default function Ambient() {
  return (
    <div className="ambient" aria-hidden="true">
      <span className="orb orb-1" />
      <span className="orb orb-2" />
      <span className="orb orb-3" />
      <span className="orb orb-4" />
      <span className="orb orb-5" />
      <span className="grain" />
    </div>
  )
}
