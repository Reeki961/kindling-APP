import { useEffect, useRef, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { exportJSON, importJSON, flushSave, writeShadowBackup, storageHealth } from '../storage/store.js'
import { audioUsage } from '../storage/audio.js'
import { THEMES, DEFAULT_THEME } from '../data/themes.js'

const KIND_LABEL = {
  question: 'Question',
  opener: 'Opener',
  rescue: 'Rescue line',
  story: 'Story',
  person: 'Person',
}

function relativeTime(iso) {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.round(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return `${Math.round(hrs / 24)}d ago`
}

export default function SettingsView() {
  const { state, dispatch } = useApp()
  const fileRef = useRef(null)
  const [importError, setImportError] = useState(null)
  const [pendingImport, setPendingImport] = useState(null)
  const [confirmReset, setConfirmReset] = useState(false)
  const [health, setHealth] = useState(null)
  const [audio, setAudio] = useState(null)
  const [shadowSaved, setShadowSaved] = useState(false)

  useEffect(() => {
    storageHealth().then(setHealth)
    audioUsage().then(setAudio)
  }, [state])

  const doExport = () => {
    exportJSON(state)
    dispatch({ type: 'MARK_BACKED_UP' })
  }

  const onFile = async (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    const text = await file.text()
    const result = importJSON(text)
    if (!result.ok) {
      setImportError(result.error)
      return
    }
    setImportError(null)
    setPendingImport(result.state)
  }

  const confirmImport = () => {
    // Snapshot what's about to be replaced, so a regretted import is recoverable.
    writeShadowBackup(state)
    dispatch({ type: 'IMPORT_STATE', state: pendingImport })
    flushSave(pendingImport)
    setPendingImport(null)
  }

  const activeTheme = state.settings.theme ?? DEFAULT_THEME
  const trash = state.trash ?? []

  const counts = {
    questions: state.questions.filter((q) => !q.deleted).length,
    myQuestions: state.questions.filter((q) => !q.deleted && q.source === 'user').length,
    openers: state.openers.filter((o) => !o.deleted).length,
    rescues: (state.rescues ?? []).filter((x) => !x.deleted).length,
    stories: state.stories.length,
    people: (state.people ?? []).length,
  }

  return (
    <div className="view">
      <h1 className="view-title">Settings</h1>
      <p className="view-sub">Your data lives only on this phone — nothing is uploaded anywhere.</p>

      <h2 className="section-h">Background mood</h2>
      <div className="theme-grid">
        {THEMES.map((t) => (
          <button
            key={t.key}
            className={`theme-swatch ${activeTheme === t.key ? 'active' : ''}`}
            onClick={() => dispatch({ type: 'SET_THEME', theme: t.key })}
          >
            <span className="dot-lg" style={{ background: t.swatch }} />
            {t.label}
          </button>
        ))}
      </div>
      <p className="settings-note">
        Rainbow slowly drifts through every colour. Calm is the quiet one — good for when you're already overstimulated.
      </p>

      <h2 className="section-h">Privacy</h2>
      <div className="group">
        <div className="group-row">
          <span className="row-label">
            Discreet text
            <span className="settings-note">Smaller and dimmer — readable by you, not by the person beside you.</span>
          </span>
          <button
            className={`toggle ${state.settings.discreet ? 'on' : ''}`}
            onClick={() => dispatch({ type: 'SET_SETTING', key: 'discreet', value: !state.settings.discreet })}
            aria-pressed={!!state.settings.discreet}
            aria-label="Discreet text"
          >
            <span className="knob" />
          </button>
        </div>
        <div className="group-row">
          <span className="row-label">
            Hide when I switch apps
            <span className="settings-note">Blanks the screen so the app switcher preview shows nothing.</span>
          </span>
          <button
            className={`toggle ${state.settings.veilOnSwitch ? 'on' : ''}`}
            onClick={() => dispatch({ type: 'SET_SETTING', key: 'veilOnSwitch', value: !state.settings.veilOnSwitch })}
            aria-pressed={!!state.settings.veilOnSwitch}
            aria-label="Hide when I switch apps"
          >
            <span className="knob" />
          </button>
        </div>
      </div>
      <p className="settings-note">
        The 🙈 button in any full-screen card blanks the app instantly. Screenshots can't be blocked by any website —
        for that you'd need a privacy screen protector.
      </p>

      <h2 className="section-h">Recently deleted</h2>
      {trash.length === 0 ? (
        <p className="settings-note">Nothing deleted recently. Anything you remove lands here first.</p>
      ) : (
        <>
          <div className="item-list">
            {trash.map((entry) => (
              <div className="item" key={entry.deletedAt}>
                <div className="item-text">
                  {entry.item.title || entry.item.text || entry.item.name || 'Untitled'}
                  <span className="item-cat">
                    {KIND_LABEL[entry.kind] ?? entry.kind} · {relativeTime(entry.deletedAt)}
                  </span>
                </div>
                <div className="item-actions">
                  <button
                    className="icon-btn"
                    onClick={() => dispatch({ type: 'RESTORE_TRASH', deletedAt: entry.deletedAt })}
                    aria-label="Restore"
                  >
                    ↩
                  </button>
                </div>
              </div>
            ))}
          </div>
          <button className="btn btn-ghost" style={{ marginTop: 10 }} onClick={() => dispatch({ type: 'CLEAR_TRASH' })}>
            Empty recently deleted
          </button>
        </>
      )}
      <p className="settings-note">Holds the last 20 things you deleted. Emptying it only clears this list.</p>

      <h2 className="section-h">Backup</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button className="btn btn-primary" onClick={doExport}>
          Export backup file
        </button>
        <button className="btn btn-ghost" onClick={() => fileRef.current?.click()}>
          Import backup file
        </button>
        <button
          className="btn btn-ghost"
          onClick={() => {
            writeShadowBackup(state)
            setShadowSaved(true)
            setTimeout(() => setShadowSaved(false), 2500)
          }}
        >
          {shadowSaved ? '✓ Safety copy updated' : 'Update in-app safety copy'}
        </button>
        <input ref={fileRef} type="file" accept="application/json,.json" style={{ display: 'none' }} onChange={onFile} />
        {importError && <div className="banner error">{importError}</div>}
        {pendingImport && (
          <div className="banner">
            <span>
              Replace everything with this backup? ({pendingImport.questions.length} questions,{' '}
              {pendingImport.stories.length} stories). Your current data is copied to the safety slot first.
            </span>
            <span style={{ display: 'flex', gap: 12 }}>
              <button onClick={confirmImport}>Replace</button>
              <button onClick={() => setPendingImport(null)}>Cancel</button>
            </span>
          </div>
        )}
        <p className="settings-note">
          Kindling keeps a second copy of everything inside this browser and restores from it automatically if the main
          data ever goes missing. That copy dies with the browser though — the exported file is the only backup that
          survives clearing site data or switching phones. Worth doing occasionally, especially on iPhone.
          <br />
          <br />
          Voice recordings are the exception: the audio itself stays on this device and is not in the export file, so
          treat recordings as practice reps rather than keepsakes.
        </p>
      </div>

      <h2 className="section-h">Content</h2>
      <button
        className="btn btn-ghost"
        onClick={() => {
          if (confirmReset) {
            dispatch({ type: 'RESET_SEEDS' })
            setConfirmReset(false)
          } else setConfirmReset(true)
        }}
      >
        {confirmReset ? 'Tap again to restore built-in content' : 'Restore built-in questions, openers & rescues'}
      </button>
      <p className="settings-note">Brings back any built-in items you deleted or edited. Your own items are untouched.</p>

      <h2 className="section-h">Your data</h2>
      <div className="group">
        {[
          ['Questions', `${counts.questions} (${counts.myQuestions} yours)`],
          ['Openers', counts.openers],
          ['Rescue lines', counts.rescues],
          ['Stories', counts.stories],
          ['People', counts.people],
          [
            'Last export',
            state.settings.lastBackupAt
              ? new Date(state.settings.lastBackupAt).toLocaleDateString()
              : 'never',
          ],
          ['Safety copy', health?.hasShadow ? 'in place' : 'not yet written'],
          [
            'Recordings',
            audio
              ? audio.count > 0
                ? `${audio.count} · ${Math.max(1, Math.round(audio.bytes / 1024))} KB`
                : '0'
              : '…',
          ],
          [
            'Space used',
            health
              ? `${Math.max(1, Math.round(health.usedBytes / 1024))} KB` +
                (health.quotaBytes ? ` of ~${Math.round(health.quotaBytes / 1024 / 1024)} MB` : '')
              : '…',
          ],
        ].map(([label, value]) => (
          <div className="group-row" key={label}>
            <span className="row-label">{label}</span>
            <span className="row-value">{value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
