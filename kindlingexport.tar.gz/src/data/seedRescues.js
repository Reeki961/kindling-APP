// Escape hatches: what to actually say when things stall, flop, or you're done.
// These are lines to use verbatim — the point is that you don't have to think.
export const RESCUE_SITUATIONS = [
  { key: 'silence', label: 'Silence' },
  { key: 'flopped', label: 'Story flopped' },
  { key: 'low-battery', label: 'Low battery' },
  { key: 'missed', label: 'Missed it' },
  { key: 'exit-convo', label: 'Leave a chat' },
  { key: 'exit-event', label: 'Leave entirely' },
  { key: 'name', label: 'Forgot name' },
  { key: 'deflect', label: 'Too personal' },
]

const r = (id, situation, text) => ({ id, situation, text })

export const seedRescues = [
  // silence — conversation died
  r('r-001', 'silence', "Okay, random question — what's the best thing you've eaten this week?"),
  r('r-002', 'silence', 'What were we talking about before this? I completely lost the thread.'),
  r('r-003', 'silence', 'Tell me something good that happened to you lately.'),
  r('r-004', 'silence', "Right — I need a refill. Do you want anything?"),
  r('r-005', 'silence', "What's everyone's plan for the rest of the week?"),
  r('r-006', 'silence', 'Honestly, comfortable silence is underrated.'),
  r('r-007', 'silence', "I've got a stupid question I've been saving. Ready?"),
  r('r-008', 'silence', "What's the last thing that properly made you laugh?"),

  // flopped — the story didn't land
  r('r-009', 'flopped', 'Okay, that was funnier in my head.'),
  r('r-010', 'flopped', "I'm now realising you had to be there."),
  r('r-011', 'flopped', 'That one works about forty percent of the time.'),
  r('r-012', 'flopped', 'Tough crowd. Fair enough.'),
  r('r-013', 'flopped', "Anyway — please, someone tell a better one."),
  r('r-014', 'flopped', 'I clearly peaked at the setup.'),
  r('r-015', 'flopped', "Let's all agree that didn't happen."),
  r('r-016', 'flopped', "That's my cake disaster — tell me someone has a worse one."),

  // low-battery — stay in the room without performing
  r('r-017', 'low-battery', 'Tell me more about that.'),
  r('r-018', 'low-battery', 'Wait, go back — what happened after that?'),
  r('r-019', 'low-battery', 'How did that actually feel?'),
  r('r-020', 'low-battery', "You explain this better than I would. Keep going."),
  r('r-021', 'low-battery', "I'm quiet tonight — don't take it personally, I'm still listening."),
  r('r-022', 'low-battery', 'Say more.'),
  r('r-023', 'low-battery', 'What made you decide that?'),
  r('r-024', 'low-battery', "Honestly I'm running on empty today, but I'm happy here."),

  // missed — you zoned out
  r('r-025', 'missed', 'Sorry, I drifted for a second — say that again?'),
  r('r-026', 'missed', 'I completely missed that and I actually want to hear it.'),
  r('r-027', 'missed', 'Rewind ten seconds for me?'),
  r('r-028', 'missed', "Sorry, it's loud in here — one more time?"),
  r('r-029', 'missed', 'My brain just left the building. What did you say?'),
  r('r-030', 'missed', 'I got distracted — start that bit again?'),

  // exit-convo — leave this conversation gracefully
  r('r-031', 'exit-convo', "I'm going to grab a drink — it was really good talking to you."),
  r('r-032', 'exit-convo', "I should say hi to a few people, but let's pick this up later."),
  r('r-033', 'exit-convo', "I'll let you mingle. Genuinely enjoyed this."),
  r('r-034', 'exit-convo', 'Before I lose you — are you on Instagram?'),
  r('r-035', 'exit-convo', 'I need the bathroom, but come find me later.'),
  r('r-036', 'exit-convo', "I'm going to go check on the host. Great to meet you."),
  r('r-037', 'exit-convo', "This has been great — I'll catch you before I head off."),
  r('r-038', 'exit-convo', "Let me get out of your way, you've got people to see."),

  // exit-event — leave entirely
  r('r-039', 'exit-event', "I'm going to head off — early start tomorrow."),
  r('r-040', 'exit-event', "I'm at my limit for tonight, but this was lovely."),
  r('r-041', 'exit-event', "I'm going to head home while I'm still good company."),
  r('r-042', 'exit-event', "Right, I'm calling it. Thank you for having me."),
  r('r-043', 'exit-event', "My battery's done — I'm going to go. Thanks for tonight."),
  r('r-044', 'exit-event', "I'll say my goodbyes now before I get roped into another hour."),
  r('r-045', 'exit-event', "I'm slipping out before I turn into a pumpkin."),
  r('r-046', 'exit-event', "Text me — I'm heading out."),

  // name — you forgot their name
  r('r-047', 'name', "I'm so sorry — remind me of your name?"),
  r('r-048', 'name', "I've completely blanked. Name again?"),
  r('r-049', 'name', 'Tell me your name once more — I want to actually keep it this time.'),
  r('r-050', 'name', "I'm terrible with names and I've lost yours."),
  r('r-051', 'name', 'Have you two met? — (then let them introduce themselves)'),
  r('r-052', 'name', 'How do you spell your name? I want to add you.'),

  // deflect — question you don't want to answer
  r('r-053', 'deflect', "Oh, that's a whole saga. Ask me when we've got more time."),
  r('r-054', 'deflect', "I'll spare you that one — what about you?"),
  r('r-055', 'deflect', "Honestly, I'd rather not get into it tonight."),
  r('r-056', 'deflect', "That's a big question for a Tuesday."),
  r('r-057', 'deflect', "Let's just say it's complicated and leave it there."),
  r('r-058', 'deflect', "I'm keeping that one to myself for now."),
  r('r-059', 'deflect', 'Next question. (with a smile)'),
  r('r-060', 'deflect', "Ask me again in a year and I'll tell you properly."),
]
