import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { SITUATIONS } from '../data/seedOpeners.js'
import ChipFilter from '../components/ChipFilter.jsx'
import ListItem from '../components/ListItem.jsx'
import EditSheet from '../components/EditSheet.jsx'
import DrawMode from './DrawMode.jsx'

const sitLabel = (key) => SITUATIONS.find((s) => s.key === key)?.label ?? key

export default function OpenersView() {
  const { state, dispatch, deleteItem, markUsed } = useApp()
  const [situation, setSituation] = useState(null)
  const [drawing, setDrawing] = useState(false)
  const [editing, setEditing] = useState(null)

  const visible = useMemo(
    () => state.openers.filter((o) => !o.deleted && (!situation || o.situation === situation)),
    [state.openers, situation]
  )

  return (
    <div className="view">
      <h1 className="view-title">Openers</h1>
      <p className="view-sub">First lines, sorted by situation. Pick the room you're in.</p>

      <button className="draw-btn" onClick={() => setDrawing(true)}>
        💬 Give me an opener{situation ? ` · ${sitLabel(situation)}` : ''}
      </button>

      <ChipFilter options={SITUATIONS} value={situation} onChange={setSituation} />

      <div className="item-list">
        {visible.map((item) => (
          <ListItem
            key={item.id}
            text={item.text}
            subLabel={sitLabel(item.situation)}
            favorite={item.favorite}
            onToggleFavorite={() => dispatch({ type: 'TOGGLE_FAVORITE_OPENER', id: item.id })}
            onEdit={() => setEditing(item)}
          />
        ))}
        {visible.length === 0 && <p className="empty-note">No openers here yet — add your own with the + button.</p>}
      </div>

      <button className="fab" onClick={() => setEditing('new')} aria-label="Add opener">＋</button>

      {drawing && (
        <DrawMode
          items={visible}
          label={situation ? sitLabel(situation) : 'Open with this'}
          onToggleFavorite={(id) => dispatch({ type: 'TOGGLE_FAVORITE_OPENER', id })}
          onMarkUsed={(id) => markUsed('opener', id)}
          onClose={() => setDrawing(false)}
        />
      )}

      {editing && (
        <EditSheet
          title={editing === 'new' ? 'New opener' : 'Edit opener'}
          categories={SITUATIONS}
          categoryLabel="Situation"
          item={editing === 'new' ? null : editing}
          defaultCategory={situation}
          onSave={(text, sit) =>
            editing === 'new'
              ? dispatch({ type: 'ADD_OPENER', text, situation: sit })
              : dispatch({ type: 'EDIT_OPENER', id: editing.id, text, situation: sit })
          }
          onDelete={editing === 'new' ? null : () => deleteItem('opener', editing.id, 'Opener')}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  )
}
