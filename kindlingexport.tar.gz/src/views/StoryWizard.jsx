import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import StoryEditor from './StoryEditor.jsx'
import BeatDistiller from './BeatDistiller.jsx'
import PracticeMode from './PracticeMode.jsx'

// Three-step flow over one story record: write → distill → practice.
export default function StoryWizard({ story, initialStep = 1, onExit }) {
  const { dispatch, deleteItem } = useApp()
  const [step, setStep] = useState(initialStep)

  const update = (patch) => dispatch({ type: 'UPDATE_STORY', id: story.id, patch })

  const exitAndCleanEmpty = () => {
    if (!story.title.trim() && !story.fullText.trim() && story.beats.filter(Boolean).length === 0) {
      dispatch({ type: 'DISCARD_EMPTY_STORY', id: story.id })
    }
    onExit()
  }

  if (step === 3) {
    return (
      <PracticeMode
        story={story}
        onDone={() => {
          dispatch({ type: 'INCREMENT_PRACTICE', id: story.id })
          onExit()
        }}
        onBack={() => setStep(2)}
        onClose={onExit}
      />
    )
  }

  return (
    <div className="view">
      <button className="back-btn" onClick={exitAndCleanEmpty}>‹ Stories</button>
      <div className="wizard-steps">
        {[1, 2, 3].map((n) => (
          <div key={n} className={`step ${step >= n ? 'on' : ''}`} />
        ))}
      </div>
      {step === 1 && (
        <StoryEditor story={story} onUpdate={update} onNext={() => setStep(2)} onDelete={() => { deleteItem('story', story.id, 'Story'); onExit() }} />
      )}
      {step === 2 && (
        <BeatDistiller story={story} onUpdate={update} onBack={() => setStep(1)} onNext={() => setStep(3)} />
      )}
    </div>
  )
}
