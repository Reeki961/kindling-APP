import { useState } from 'react'

// Bottom-sheet add/edit form for a question or opener.
// `categories` = [{key, label}]; `item` = existing item or null for new.
export default function EditSheet({ title, categories, categoryLabel, item, defaultCategory, onSave, onDelete, onClose }) {
  const [text, setText] = useState(item?.text ?? '')
  const [category, setCategory] = useState(item?.category ?? item?.situation ?? defaultCategory ?? categories[0].key)
  const [confirmDelete, setConfirmDelete] = useState(false)

  const save = () => {
    const trimmed = text.trim()
    if (!trimmed) return
    onSave(trimmed, category)
    onClose()
  }

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        <textarea
          autoFocus
          rows={3}
          value={text}
          placeholder="Write it the way you'd actually say it…"
          onChange={(e) => setText(e.target.value)}
        />
        <label>
          <span className="settings-note">{categoryLabel}</span>
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {categories.map((c) => (
              <option key={c.key} value={c.key}>
                {c.label}
              </option>
            ))}
          </select>
        </label>
        <div className="sheet-row">
          <button className="btn btn-ghost" onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={save} disabled={!text.trim()}>
            Save
          </button>
        </div>
        {item && onDelete && (
          <button
            className="btn btn-danger"
            onClick={() => {
              if (confirmDelete) {
                onDelete()
                onClose()
              } else setConfirmDelete(true)
            }}
          >
            {confirmDelete ? 'Tap again to delete' : 'Delete'}
          </button>
        )}
      </div>
    </div>
  )
}
