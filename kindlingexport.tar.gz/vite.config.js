import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['apple-touch-icon.png'],
      // /share is a virtual route — the SPA fallback serves index.html and the app
      // reads the shared text out of the query string.
      workbox: { navigateFallback: 'index.html' },
      manifest: {
        name: 'Kindling',
        short_name: 'Kindling',
        description: 'Pocket conversation questions, openers, and storytelling practice',
        start_url: '/',
        display: 'standalone',
        // Lets Kindling appear in the OS share sheet, so an interesting question
        // can be sent straight in from anywhere instead of retyped.
        share_target: {
          action: '/share',
          method: 'GET',
          params: { title: 'title', text: 'text', url: 'url' },
        },
        background_color: '#08070a',
        theme_color: '#08070a',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
        ]
      }
    })
  ]
})
