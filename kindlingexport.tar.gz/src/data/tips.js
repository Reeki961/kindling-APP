// Storytelling guides. Each section body is an array of paragraphs; `list` renders bullets.
export const tips = [
  {
    id: 'tip-structure',
    title: 'Story structure: setup, turn, payoff',
    tagline: 'Every good spoken story is three moves, not a novel.',
    sections: [
      {
        heading: 'The three moves',
        body: [
          'A spoken story only needs three parts. The SETUP puts us somewhere: where you were, what was normal, what you expected. The TURN is the moment something broke the normal: a surprise, a mistake, a decision, a stranger. The PAYOFF is what happened because of it — the punchline, the lesson, the image people remember.',
        ],
        list: [
          'Setup: "So last summer I\'m at my cousin\'s wedding, and I\'m in charge of the cake."',
          'Turn: "Halfway through the drive, I hit a speed bump and hear a soft thud from the back seat."',
          'Payoff: "So that\'s why, in every wedding photo, the cake is mysteriously only two layers tall."',
        ],
      },
      {
        heading: 'Why writing this down first works',
        body: [
          'If you write easily, use it. Write the story out fully once — every detail, no filter. Then find the three moves inside it and throw the rest away. Speaking a story is not reading an essay aloud; it is walking through three rooms you know well. The writing builds the rooms. The telling is just the walk.',
          'When you can name your setup, turn, and payoff in one short line each, you know the story well enough to tell it. If you cannot, the story is not ready — and that is a writing problem, which you are good at solving.',
        ],
      },
    ],
  },
  {
    id: 'tip-beats',
    title: 'The beat method',
    tagline: 'Memorize five images, not two hundred words.',
    sections: [
      {
        heading: 'What a beat is',
        body: [
          'A beat is a cue, not a sentence — under eight words, mostly nouns and images. "Airport. Wrong gate. Sprinting." is a beat. "Then I realized I had been waiting at the wrong gate so I had to run" is a script, and scripts are the enemy: the moment you forget one word of a script, you freeze.',
          'Beats work because your memory for images is far stronger than your memory for sentences. You will never say the story the same way twice, and that is exactly what makes it sound natural instead of rehearsed.',
        ],
      },
      {
        heading: 'How to distill',
        body: [
          'Take your written story and mark the 3–5 moments that HAVE to happen for the ending to land. Each one becomes a beat. Everything else — the transitions, the exact wording, the extra details — you improvise fresh each time, and you are allowed to improvise it differently every time.',
        ],
        list: [
          'Beat 1 is always the setup: place + what was normal.',
          'One beat is always the turn: the moment it went sideways.',
          'The last beat is the payoff — know your final line almost exactly; it\'s the one thing worth memorizing word-for-word.',
          'Middle beats: only the details the ending depends on.',
        ],
      },
      {
        heading: 'Practicing with beats',
        body: [
          'Tell the story out loud — actually out loud, alone, to your phone, to a pet — looking only at the beats. The first telling will be clumsy. The third will be fine. The fifth will be yours. This is the single highest-value habit in this entire app.',
        ],
      },
    ],
  },
  {
    id: 'tip-start-strong',
    title: 'Starting strong: skip the preamble',
    tagline: 'Start inside the story, not outside of it.',
    sections: [
      {
        heading: 'Kill the throat-clearing',
        body: [
          'Weak starts sound like: "Okay so this is kind of a long story, I don\'t know if I\'m telling it right, but basically, so like two years ago — no wait, three...". Every one of those words tells the listener "you can stop listening." Strong starts drop us straight into a scene: "So I\'m standing in line at customs, and the officer looks at my passport, then at me, then back at the passport."',
        ],
        list: [
          'Never apologize before a story ("this is probably boring, but...").',
          'Never start with the date debate ("was it 2019? no, 2020, because...") — nobody needs the exact year.',
          'Start with "So I\'m..." in present tense. It teleports people into the scene instantly.',
        ],
      },
      {
        heading: 'The first-line trick',
        body: [
          'When you distill a story into beats, write your actual opening sentence and keep it. A prepared first line removes the hardest moment — the cold start — and after one good sentence, momentum carries you. It is the same trick as diving into a pool instead of inching in.',
        ],
      },
    ],
  },
  {
    id: 'tip-detail',
    title: 'Sensory detail: the one-detail rule',
    tagline: 'One specific detail beats ten general ones.',
    sections: [
      {
        heading: 'Specific is better than complete',
        body: [
          'You do not need to describe everything — you need ONE detail so specific it proves you were there. Not "the restaurant was fancy" but "the menu didn\'t have prices." Not "the dog was big" but "the dog had its own armchair." Listeners build the whole scene themselves around one true detail.',
          'When you write your story out, you will naturally produce lots of detail — that is your strength. During distilling, pick the single best detail per beat and cut the rest without mercy. The cut details are not wasted: they are your spare parts when someone asks a follow-up question.',
        ],
      },
      {
        heading: 'Details that always work',
        body: [],
        list: [
          'Exact numbers: "forty-five minutes", "the third try", "eleven p.m."',
          'What someone actually said, word for word, in their voice.',
          'The out-of-place object: the thing that did not belong in the scene.',
          'Your inner monologue at the time: "and I\'m thinking: I am going to die at a mini-golf course."',
        ],
      },
    ],
  },
  {
    id: 'tip-pacing',
    title: 'Pacing and the pause',
    tagline: 'Slow is confident. Silence is a tool.',
    sections: [
      {
        heading: 'Speed is the tell',
        body: [
          'Nervous storytellers speed up, trying to finish before they lose the room. It works backwards: speed makes people tune out, and slowness reads as confidence. You have more time than you think — a story told 30% slower than feels natural usually sounds exactly right to listeners.',
        ],
      },
      {
        heading: 'The pause before the payoff',
        body: [
          'Right before your final beat — the punchline, the reveal — stop. One full second. It feels like an eternity to you and like electricity to everyone else. The pause tells the room "here it comes," and it makes even a medium ending land like a good one.',
        ],
        list: [
          'Pause after the turn, too: "...and I hear a soft thud. (beat) From the back seat."',
          'If you lose your place, pause instead of saying "um" — a silent pause looks thoughtful; a filled one sounds lost.',
          'Breathe at the commas. Rushing is usually just forgetting to breathe.',
        ],
      },
    ],
  },
  {
    id: 'tip-ending',
    title: 'Landing the ending',
    tagline: 'Know your last line. Then stop talking.',
    sections: [
      {
        heading: 'The one thing to memorize',
        body: [
          'Improvise everything except the ending. Your final line is the only part of a story worth knowing word-for-word, because it is the part people remember and the part that signals "you can laugh/react now." A story without a planned ending trails off: "...yeah, so, that happened, anyway." That "anyway" is where good stories go to die.',
        ],
      },
      {
        heading: 'Shapes of a good last line',
        body: [],
        list: [
          'The callback: reuse a phrase or object from your setup ("...and that\'s why the cake is two layers tall.").',
          'The consequence: what is permanently different now ("I still can\'t hear that song without checking my pockets.").',
          'The confession: what you were really thinking ("And honestly? I\'d do it again.").',
          'The quote: the exact thing someone said that summed it all up.',
        ],
      },
      {
        heading: 'Then actually stop',
        body: [
          'When the line lands — stop. Do not explain the ending, do not add "so yeah." Trust it. Silence after a last line is not awkward; it is the space where the reaction happens.',
        ],
      },
    ],
  },
  {
    id: 'tip-rescue',
    title: 'Rescuing a flopped story',
    tagline: 'Every storyteller bombs. The recovery is the skill.',
    sections: [
      {
        heading: 'Flops are normal',
        body: [
          'Every good storyteller regularly tells stories that land flat. The difference is they do not treat a flop as evidence they cannot tell stories — they treat it as data about that story, that room, that day. A story that flops at work might kill at a party. Keep the story; change the audience or trim the middle.',
        ],
      },
      {
        heading: 'In-the-moment saves',
        body: [],
        list: [
          'Name it lightly: "Okay, that was funnier in my head." Self-aware beats embarrassed, and it usually gets the laugh the story missed.',
          'Hand off: "...anyway, that\'s my cake disaster — please tell me someone has a worse wedding story." A flopped story that starts a better conversation did its job.',
          'Do not re-explain. If the punchline missed, explaining it buries it. Let it go and move on.',
          'Shorten on the fly: if you feel the room drifting mid-story, jump straight to your last beat. Nobody ever complained a story was too short.',
        ],
      },
      {
        heading: 'Afterwards',
        body: [
          'Later, in this app, look at the beats: was the setup too long? Was the payoff clear? Fix the beats, not your self-esteem. A story is a draft, and you are good at editing drafts.',
        ],
      },
    ],
  },
  {
    id: 'tip-low-battery',
    title: 'Running on empty',
    tagline: "When you've got nothing left, listening is a full contribution.",
    sections: [
      {
        heading: 'You do not owe anyone a performance',
        body: [
          'The trap of low-battery socialising is believing you have to be entertaining or you are failing. You are not. Conversations need listeners far more than they need performers, and most people leave a conversation rating it on how much THEY got to say — not on how impressive you were.',
          'On an empty tank, switch roles deliberately: stop trying to produce material and start pulling it out of other people. It costs almost nothing and it reads as warmth, not withdrawal.',
        ],
      },
      {
        heading: 'The four-word toolkit',
        body: [
          'You can run an entire evening on a handful of short prompts. Each one hands the floor back and buys you thirty seconds of rest.',
        ],
        list: [
          '"Tell me more about that."',
          '"How did that feel?"',
          '"Wait, go back — what happened after?"',
          '"What made you decide that?"',
          'And the underrated one: repeat their last three words back as a question. "...he just left?"',
        ],
      },
      {
        heading: 'Name it instead of faking it',
        body: [
          'If you go quiet without explanation, people fill the gap with a story — usually that you are bored or annoyed with them. One short honest line prevents all of it: "I\'m quiet tonight, don\'t take it personally, I\'m still listening." Almost nobody reacts badly to that, and it removes the pressure to keep proving you are engaged.',
        ],
      },
      {
        heading: 'Leave before you are empty, not after',
        body: [
          'The version of you that leaves at 90 minutes is remembered warmly. The version that white-knuckles it to hour four is remembered as the person who went strange and quiet. Leaving early is not a failure — it is the thing that makes you willing to come next time.',
          'Have your exit line ready before you arrive, so leaving takes no energy to invent. The Rescue tab has them.',
        ],
      },
    ],
  },
  {
    id: 'tip-segues',
    title: 'Segues: matching stories to conversations',
    tagline: 'A story needs a doorway, not an announcement.',
    sections: [
      {
        heading: 'Listen for doorways',
        body: [
          'The natural way into a story is through what someone just said. Someone mentions airports → your airport story has a doorway. The formula is one connecting line: "Oh no — I once [one-line version]. Do you want the full story?" That last question matters: it gets you an invited audience instead of a captive one, and an invited audience wants you to succeed.',
        ],
      },
      {
        heading: 'Build your story index',
        body: [
          'For each story you keep in this app, know its TRIGGERS: the topics that open a doorway to it. The cake story\'s triggers might be weddings, driving, disasters, cake. When a trigger comes up in conversation, you will feel the doorway open. This is also the fix for "I never know what to say" — you are not searching your whole life in real time, just checking a short index you already built.',
        ],
        list: [
          'Keep a one-line version of every story ready — the trailer, not the film.',
          'If the doorway closes (topic moves on), let the story go. There will be another doorway.',
          'Reciprocity: after your story, hand the floor back — "has anything like that happened to you?" Stories are trades, not performances.',
        ],
      },
    ],
  },
]
