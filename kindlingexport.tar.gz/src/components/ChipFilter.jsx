export default function ChipFilter({ options, value, onChange, allLabel = 'All' }) {
  return (
    <div className="chips">
      <button className={`chip ${value === null ? 'active' : ''}`} onClick={() => onChange(null)}>
        {allLabel}
      </button>
      {options.map((opt) => (
        <button
          key={opt.key}
          className={`chip ${value === opt.key ? 'active' : ''}`}
          onClick={() => onChange(value === opt.key ? null : opt.key)}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}
