import { useState } from 'react'

const BEAT_PROMPTS = [
  'Beat 1 — the setup: where were you, what was normal?',
  'Beat 2 — the turn: what went wrong or surprised you?',
  'Beat 3 — escalation: a detail the ending depends on',
  'Beat 4 — (optional) one more image worth keeping',
  'Beat 5 — the payoff: your closing line, almost word-for-word',
]

// Step 2: distill the written story into 3–5 short beat cues.
export default function BeatDistiller({ story, onUpdate, onBack, onNext }) {
  const [showFull, setShowFull] = useState(true)
  const beats = [...story.beats]
  while (beats.length < 5) beats.push('')

  const setBeat = (i, value) => {
    const next = [...beats]
    next[i] = value
    onUpdate({ beats: next })
  }

  const filled = beats.filter((b) => b.trim()).length

  return (
    <>
      <h1 className="view-title">Distill into beats</h1>
      <p className="view-sub">Find the 3–5 moments the ending depends on. Everything else you'll improvise fresh.</p>

      <button className="collapse-toggle" onClick={() => setShowFull(!showFull)}>
        {showFull ? '▾ Hide your story' : '▸ Show your story'}
      </button>
      {showFull && <div className="story-fulltext">{story.fullText}</div>}

      <div className="hint-panel">
        Keep each beat under ~8 words — nouns and images, not sentences. "Airport. Wrong gate. Sprinting." beats a
        paragraph. The last beat is your closing line: that one, keep word-for-word.
      </div>

      <div className="beat-input-group">
        {beats.map((beat, i) => (
          <div className="beat-row" key={i}>
            <span className="beat-num">{i + 1}</span>
            <input value={beat} placeholder={BEAT_PROMPTS[i]} onChange={(e) => setBeat(i, e.target.value)} />
          </div>
        ))}
      </div>

      <div className="sheet-row" style={{ marginTop: 16 }}>
        <button className="btn btn-ghost" onClick={onBack}>
          ‹ Back to writing
        </button>
        <button className="btn btn-primary" onClick={onNext} disabled={filled < 3}>
          Practice ›
        </button>
      </div>
      {filled < 3 && <p className="settings-note">Fill at least 3 beats to start practicing.</p>}
    </>
  )
}
