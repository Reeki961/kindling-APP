import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import SearchBar from '../components/SearchBar.jsx'

// What you learned about someone, so you have a hook next time you see them.
function PersonSheet({ person, onSave, onDelete, onClose }) {
  const [name, setName] = useState(person?.name ?? '')
  const [notes, setNotes] = useState(person?.notes ?? '')
  const [confirmDelete, setConfirmDelete] = useState(false)

  const save = () => {
    if (!name.trim()) return
    onSave(name.trim(), notes)
    onClose()
  }

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <h3>{person ? 'Edit person' : 'New person'}</h3>
        <input
          autoFocus
          value={name}
          placeholder="Name"
          onChange={(e) => setName(e.target.value)}
        />
        <textarea
          rows={6}
          value={notes}
          placeholder={"What did you learn?\n\nHas a brother in Leeds. Hates coriander.\nAsk about the marathon next time."}
          onChange={(e) => setNotes(e.target.value)}
        />
        <div className="sheet-row">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={!name.trim()}>Save</button>
        </div>
        {person && onDelete && (
          <button
            className="btn btn-danger"
            onClick={() => {
              if (confirmDelete) { onDelete(); onClose() } else setConfirmDelete(true)
            }}
          >
            {confirmDelete ? 'Tap again to delete' : 'Delete'}
          </button>
        )}
      </div>
    </div>
  )
}

export default function PeopleView() {
  const { state, dispatch, deleteItem } = useApp()
  const [search, setSearch] = useState('')
  const [editing, setEditing] = useState(null) // null | 'new' | person

  const people = state.people ?? []

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return people
    return people.filter(
      (p) => p.name.toLowerCase().includes(q) || p.notes.toLowerCase().includes(q)
    )
  }, [people, search])

  return (
    <div className="view">
      <h1 className="view-title">People</h1>
      <p className="view-sub">
        What you learned last time, so you always have somewhere to start.
      </p>

      {people.length > 3 && (
        <SearchBar value={search} onChange={setSearch} placeholder="Search people or notes…" />
      )}

      <div className="item-list">
        {visible.map((p) => (
          <div className="item" key={p.id}>
            <button className="item-text" style={{ textAlign: 'left' }} onClick={() => setEditing(p)}>
              {p.name}
              {p.notes.trim() && <span className="person-notes">{p.notes}</span>}
            </button>
            <div className="item-actions">
              <button className="icon-btn" onClick={() => setEditing(p)} aria-label="Edit person">✎</button>
            </div>
          </div>
        ))}
        {people.length === 0 && (
          <p className="empty-note">
            Nobody yet. After you next talk to someone, jot down one thing they said — that's your opening line for
            the time after.
          </p>
        )}
        {people.length > 0 && visible.length === 0 && (
          <p className="empty-note">Nobody matches "{search}".</p>
        )}
      </div>

      <button className="fab" onClick={() => setEditing('new')} aria-label="Add person">＋</button>

      {editing && (
        <PersonSheet
          person={editing === 'new' ? null : editing}
          onSave={(name, notes) =>
            editing === 'new'
              ? dispatch({ type: 'ADD_PERSON', name, notes })
              : dispatch({ type: 'EDIT_PERSON', id: editing.id, name, notes })
          }
          onDelete={editing === 'new' ? null : () => deleteItem('person', editing.id, 'Person')}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  )
}
