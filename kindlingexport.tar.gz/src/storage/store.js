// Persistence layer. All data lives in one localStorage document under STORE_KEY,
// with a shadow copy under BACKUP_KEY that is only written when the app backgrounds.
// Swap this module's internals if storage ever needs to move to IndexedDB.
import { seedQuestions } from '../data/seedQuestions.js'
import { seedOpeners } from '../data/seedOpeners.js'
import { seedRescues } from '../data/seedRescues.js'
import { DEFAULT_THEME } from '../data/themes.js'

export const STORE_KEY = 'kindling.v1'
export const BACKUP_KEY = 'kindling.v1.backup'
const CURRENT_SCHEMA = 4
const SEED_VERSION = 3
export const TRASH_LIMIT = 20
export const PRACTICE_LOG_LIMIT = 400

const usageFields = { favorite: false, source: 'seed', deleted: false, usedCount: 0, lastUsedAt: null }

function seededQuestion(s) {
  return { id: s.id, text: s.text, category: s.category, tags: [], ...usageFields }
}
function seededOpener(s) {
  return { id: s.id, text: s.text, situation: s.situation, ...usageFields }
}
function seededRescue(s) {
  return { id: s.id, text: s.text, situation: s.situation, ...usageFields }
}

export function initialState() {
  return {
    schemaVersion: CURRENT_SCHEMA,
    questions: seedQuestions.map(seededQuestion),
    openers: seedOpeners.map(seededOpener),
    rescues: seedRescues.map(seededRescue),
    stories: [],
    people: [],
    trash: [],
    practiceLog: [],
    settings: {
      lastBackupAt: null,
      seedVersion: SEED_VERSION,
      theme: DEFAULT_THEME,
      discreet: false,
      veilOnSwitch: false,
    },
  }
}

export function migrate(raw) {
  const doc = { ...raw }
  const from = doc.schemaVersion || 1

  // Defensive first: never operate on a document missing a collection.
  doc.questions = Array.isArray(doc.questions) ? doc.questions : []
  doc.openers = Array.isArray(doc.openers) ? doc.openers : []
  doc.stories = Array.isArray(doc.stories) ? doc.stories : []
  doc.trash = Array.isArray(doc.trash) ? doc.trash : []

  // v1 → v2: rescue lines and the undo trash did not exist yet.
  doc.rescues = Array.isArray(doc.rescues)
    ? doc.rescues
    : from < 2
      ? seedRescues.map(seededRescue)
      : []

  // v2 → v3: usage tracking, story triggers, recordings, practice history.
  doc.practiceLog = Array.isArray(doc.practiceLog) ? doc.practiceLog : []
  for (const key of ['questions', 'openers', 'rescues']) {
    doc[key] = doc[key].map((x) => ({ usedCount: 0, lastUsedAt: null, ...x }))
  }
  doc.stories = doc.stories.map((s) => ({ triggers: [], recordings: [], ...s }))

  // v3 → v4: people you want to remember things about.
  doc.people = Array.isArray(doc.people) ? doc.people : []

  doc.settings = {
    lastBackupAt: null,
    seedVersion: 0,
    theme: DEFAULT_THEME,
    discreet: false,
    veilOnSwitch: false,
    ...(doc.settings || {}),
  }
  doc.schemaVersion = CURRENT_SCHEMA
  return doc
}

// Deliberately tolerant of collections added in later schema versions —
// migrate() fills those in. Only the v1 core is required to call a document valid.
export function validateShape(doc) {
  return (
    doc &&
    typeof doc === 'object' &&
    !Array.isArray(doc) &&
    typeof doc.schemaVersion === 'number' &&
    Array.isArray(doc.questions) &&
    Array.isArray(doc.openers) &&
    Array.isArray(doc.stories) &&
    doc.questions.every((x) => x && typeof x.text === 'string') &&
    doc.openers.every((x) => x && typeof x.text === 'string') &&
    doc.stories.every((x) => x && typeof x.title === 'string')
  )
}

// What happened on the last loadState() — surfaced to the user when it matters.
// loadState() repairs the main document as a side effect, so a second call in the
// same page session (React StrictMode double-invokes initialisers) would otherwise
// report a clean load and hide the fact that a recovery just happened. These latch.
let loadReport = { source: 'fresh', recovered: false, storageAvailable: true }
let recoveredThisSession = false
let wipedThisSession = false

export function getLoadReport() {
  return {
    ...loadReport,
    recovered: loadReport.recovered || recoveredThisSession,
    wipedCorrupt: loadReport.wipedCorrupt || wipedThisSession,
  }
}

function storageWorks() {
  try {
    const probe = '__kindling_probe__'
    localStorage.setItem(probe, '1')
    localStorage.removeItem(probe)
    return true
  } catch {
    return false
  }
}

function readDoc(key) {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return null
    const doc = JSON.parse(raw)
    return validateShape(doc) ? doc : null
  } catch {
    return null
  }
}

export function loadState() {
  if (!storageWorks()) {
    loadReport = { source: 'fresh', recovered: false, storageAvailable: false }
    return initialState()
  }
  // Main document first, then the shadow copy, then a clean slate.
  const main = readDoc(STORE_KEY)
  if (main) {
    loadReport = { source: 'main', recovered: false, storageAvailable: true }
    return mergeNewSeeds(migrate(main))
  }
  const shadow = readDoc(BACKUP_KEY)
  if (shadow) {
    loadReport = { source: 'backup', recovered: true, storageAvailable: true }
    recoveredThisSession = true
    const restored = mergeNewSeeds(migrate(shadow))
    write(STORE_KEY, restored)
    return restored
  }
  const hadSomething = (() => {
    try {
      return localStorage.getItem(STORE_KEY) !== null
    } catch {
      return false
    }
  })()
  if (hadSomething) wipedThisSession = true
  loadReport = { source: 'fresh', recovered: false, storageAvailable: true, wipedCorrupt: hadSomething }
  return initialState()
}

// When the app ships new seed content (SEED_VERSION bump), add only unseen seed ids.
function mergeNewSeeds(state) {
  if ((state.settings?.seedVersion ?? 0) >= SEED_VERSION) return state
  const qIds = new Set(state.questions.map((x) => x.id))
  const oIds = new Set(state.openers.map((x) => x.id))
  const rIds = new Set(state.rescues.map((x) => x.id))
  return {
    ...state,
    questions: [...state.questions, ...seedQuestions.filter((s) => !qIds.has(s.id)).map(seededQuestion)],
    openers: [...state.openers, ...seedOpeners.filter((s) => !oIds.has(s.id)).map(seededOpener)],
    rescues: [...state.rescues, ...seedRescues.filter((s) => !rIds.has(s.id)).map(seededRescue)],
    settings: { ...state.settings, seedVersion: SEED_VERSION },
  }
}

let saveTimer = null
let quotaListener = null
export function onQuotaExceeded(fn) {
  quotaListener = fn
}

function write(key, state) {
  try {
    localStorage.setItem(key, JSON.stringify(state))
    return true
  } catch (e) {
    if (quotaListener) quotaListener(e)
    return false
  }
}

export function saveState(state, { immediate = false } = {}) {
  if (saveTimer) clearTimeout(saveTimer)
  if (immediate) {
    write(STORE_KEY, state)
    return
  }
  saveTimer = setTimeout(() => write(STORE_KEY, state), 200)
}

export function flushSave(state) {
  saveState(state, { immediate: true })
}

// Shadow copy — written when the app backgrounds, so a corrupted or cleared main
// document can be recovered on the next open.
export function writeShadowBackup(state) {
  return write(BACKUP_KEY, state)
}

export async function storageHealth() {
  const report = { available: storageWorks(), usedBytes: 0, quotaBytes: null, hasShadow: false }
  try {
    report.usedBytes = (localStorage.getItem(STORE_KEY) || '').length
    report.hasShadow = localStorage.getItem(BACKUP_KEY) !== null
  } catch {
    /* storage unavailable — leave defaults */
  }
  try {
    if (navigator.storage?.estimate) {
      const est = await navigator.storage.estimate()
      report.quotaBytes = est.quota ?? null
    }
  } catch {
    /* estimate unsupported */
  }
  return report
}

// Restore seeded items (undelete + reset text) without touching user-created items.
export function resetSeeds(state) {
  const restoreFrom = (list, seeds, build, keyName) => {
    const bySeed = new Map(seeds.map((s) => [s.id, s]))
    const restored = list.map((item) => {
      const seed = bySeed.get(item.id)
      return seed ? { ...item, text: seed.text, [keyName]: seed[keyName], deleted: false } : item
    })
    const ids = new Set(restored.map((x) => x.id))
    return [...restored, ...seeds.filter((s) => !ids.has(s.id)).map(build)]
  }
  return {
    ...state,
    questions: restoreFrom(state.questions, seedQuestions, seededQuestion, 'category'),
    openers: restoreFrom(state.openers, seedOpeners, seededOpener, 'situation'),
    rescues: restoreFrom(state.rescues, seedRescues, seededRescue, 'situation'),
  }
}

export function exportJSON(state) {
  const stamp = new Date().toISOString().slice(0, 10)
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `kindling-backup-${stamp}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 5000)
}

// Last-resort export that reads localStorage directly rather than React state —
// used by the crash screen, where app state may be exactly what's broken.
export function exportRawBackup() {
  let raw = null
  try {
    raw = localStorage.getItem(STORE_KEY) || localStorage.getItem(BACKUP_KEY)
  } catch {
    return false
  }
  if (!raw) return false
  const stamp = new Date().toISOString().slice(0, 10)
  const blob = new Blob([raw], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `kindling-rescue-${stamp}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 5000)
  return true
}

export function importJSON(fileText) {
  try {
    const doc = JSON.parse(fileText)
    if (!validateShape(doc)) return { ok: false, error: 'That file does not look like a Kindling backup.' }
    return { ok: true, state: migrate(doc) }
  } catch {
    return { ok: false, error: 'Could not read that file — it is not valid JSON.' }
  }
}
