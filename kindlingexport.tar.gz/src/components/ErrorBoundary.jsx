import React from 'react'
import { exportRawBackup } from '../storage/store.js'

// Last line of defence. A render error would otherwise leave a blank screen with
// the user's questions and stories locked inside localStorage — so this offers a
// direct export path that never touches app state.
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { error: null, saved: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  render() {
    if (!this.state.error) return this.props.children

    return (
      <div className="view crash">
        <h1 className="view-title">Something broke</h1>
        <p className="view-sub">
          Kindling hit an error and couldn't draw the screen. Your saved questions and stories are still on this device
          — save a copy before doing anything else.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <button
            className="btn btn-primary"
            onClick={() => this.setState({ saved: exportRawBackup() ? 'ok' : 'empty' })}
          >
            {this.state.saved === 'ok' ? '✓ Backup saved' : 'Save my data to a file'}
          </button>
          {this.state.saved === 'empty' && (
            <div className="banner error">Nothing was stored on this device yet, so there is nothing to save.</div>
          )}
          <button className="btn btn-ghost" onClick={() => window.location.reload()}>
            Reload the app
          </button>
        </div>

        <p className="settings-note">
          If reloading keeps landing here, clear this site's data and import the file you just saved.
        </p>
        <pre className="crash-detail">{String(this.state.error?.message || this.state.error)}</pre>
      </div>
    )
  }
}
