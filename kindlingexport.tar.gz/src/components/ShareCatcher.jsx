import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { QUESTION_CATEGORIES } from '../data/seedQuestions.js'
import { SITUATIONS } from '../data/seedOpeners.js'
import { RESCUE_SITUATIONS } from '../data/seedRescues.js'

const TARGETS = [
  { kind: 'question', label: 'Question', action: 'ADD_QUESTION', field: 'category', options: QUESTION_CATEGORIES },
  { kind: 'opener', label: 'Opener', action: 'ADD_OPENER', field: 'situation', options: SITUATIONS },
  { kind: 'rescue', label: 'Rescue line', action: 'ADD_RESCUE', field: 'situation', options: RESCUE_SITUATIONS },
]

// Handles text arriving from the OS share sheet (manifest share_target → /share).
export default function ShareCatcher({ shared, onClose }) {
  const { dispatch } = useApp()
  const [text, setText] = useState(shared)
  const [target, setTarget] = useState(TARGETS[0])
  const [bucket, setBucket] = useState(TARGETS[0].options[0].key)

  const save = () => {
    const trimmed = text.trim()
    if (!trimmed) return
    dispatch({ type: target.action, text: trimmed, [target.field]: bucket })
    onClose()
  }

  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <h3>Save to Kindling</h3>
        <textarea rows={4} value={text} onChange={(e) => setText(e.target.value)} />

        <div className="chips" style={{ paddingBottom: 4 }}>
          {TARGETS.map((t) => (
            <button
              key={t.kind}
              className={`chip ${target.kind === t.kind ? 'active' : ''}`}
              onClick={() => {
                setTarget(t)
                setBucket(t.options[0].key)
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        <select value={bucket} onChange={(e) => setBucket(e.target.value)}>
          {target.options.map((o) => (
            <option key={o.key} value={o.key}>
              {o.label}
            </option>
          ))}
        </select>

        <div className="sheet-row">
          <button className="btn btn-ghost" onClick={onClose}>
            Discard
          </button>
          <button className="btn btn-primary" onClick={save} disabled={!text.trim()}>
            Save
          </button>
        </div>
      </div>
    </div>
  )
}
