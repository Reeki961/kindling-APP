import { useEffect, useRef } from 'react'

// Transient one-tap path back after a delete. The item is in the trash regardless,
// so dismissing this is never destructive — Settings still has "Recently deleted".
export default function UndoToast({ label, onUndo, onDismiss, duration = 6000 }) {
  // Held in a ref so a parent re-render doesn't re-run the effect and restart
  // the countdown. App also keys this component per delete, so each new toast
  // mounts fresh and gets its own full window.
  const dismissRef = useRef(onDismiss)
  dismissRef.current = onDismiss

  useEffect(() => {
    const t = setTimeout(() => dismissRef.current(), duration)
    return () => clearTimeout(t)
  }, [duration])

  return (
    <div className="toast" role="status">
      <span>{label} deleted</span>
      <button onClick={onUndo}>Undo</button>
    </div>
  )
}
