// Conversation openers by situation — phrased as natural first lines, not interview questions.
export const SITUATIONS = [
  { key: 'party', label: 'Party' },
  { key: 'work', label: 'Work' },
  { key: 'one-on-one', label: 'One-on-one' },
  { key: 'strangers', label: 'Strangers' },
  { key: 'group', label: 'Group hangout' },
  { key: 'online-date', label: 'Online / date' },
]

const o = (id, situation, text) => ({ id, situation, text })

export const seedOpeners = [
  // party (10)
  o('o-001', 'party', 'How do you know the host? There has to be a story there.'),
  o('o-002', 'party', "I'm doing a very scientific poll: best snack on that table?"),
  o('o-003', 'party', 'You look like you know people here — I basically know one person. Help me out?'),
  o('o-004', 'party', "This song is taking me back. What's the first concert you ever went to?"),
  o('o-005', 'party', "I always end up in the kitchen at these things. Is that a universal law?"),
  o('o-006', 'party', "Okay, settle something: is it too early to leave a party at ten?"),
  o('o-007', 'party', "What's the best party you've ever been to? I need the bar to compare this one against."),
  o('o-008', 'party', "I like your [jacket/shoes/anything genuine] — is there a story behind it?"),
  o('o-009', 'party', 'Are you a "talk to everyone" person or a "find one good conversation" person?'),
  o('o-010', 'party', "If you could teleport out of here to any food right now, what are you eating?"),

  // work (10)
  o('o-011', 'work', 'How did you end up in this line of work? Nobody ever seems to have a straight path.'),
  o('o-012', 'work', "What's keeping you busy this week — anything interesting in the mix?"),
  o('o-013', 'work', "What's the part of your job you'd keep even if you won the lottery?"),
  o('o-014', 'work', 'Any good lunch spots around here I should know about?'),
  o('o-015', 'work', "How's your week pacing — sprint or marathon?"),
  o('o-016', 'work', "What did you want to be before you ended up doing this?"),
  o('o-017', 'work', "What's the best work advice anyone ever gave you?"),
  o('o-018', 'work', "Working on anything outside of work that you're excited about?"),
  o('o-019', 'work', "If your job had a highlight reel this month, what would be on it?"),
  o('o-020', 'work', "What's something about your job people always get wrong?"),

  // one-on-one (10)
  o('o-021', 'one-on-one', "What's been the best part of your month so far?"),
  o('o-022', 'one-on-one', "I feel like we always talk about surface stuff — what's actually going on with you lately?"),
  o('o-023', 'one-on-one', "What are you looking forward to right now, big or small?"),
  o('o-024', 'one-on-one', 'Have you eaten anywhere great recently? I need recommendations.'),
  o('o-025', 'one-on-one', "What's the last thing you got completely absorbed in?"),
  o('o-026', 'one-on-one', 'On a scale of one to ten, how is life actually going — and what would make it one point higher?'),
  o('o-027', 'one-on-one', "What's the most interesting thing that happened to you this week?"),
  o('o-028', 'one-on-one', "I heard something today that made me think of you — do you have strong opinions about [topic]?"),
  o('o-029', 'one-on-one', 'What are you watching or reading these days? Sell me on it.'),
  o('o-030', 'one-on-one', "If we had a totally free Saturday together, what would we do?"),

  // strangers (10)
  o('o-031', 'strangers', 'Is this seat taken? ...So, are you from around here?'),
  o('o-032', 'strangers', "This line is not moving. What's the longest you've ever waited for something that was worth it?"),
  o('o-033', 'strangers', 'That looks good — what did you order?'),
  o('o-034', 'strangers', "Excuse me, I need a tiebreaker: [small choice you're making]. Which one?"),
  o('o-035', 'strangers', 'Do you know this neighborhood? I keep hearing there are hidden gems.'),
  o('o-036', 'strangers', "I like your [bag/book/dog] — there's got to be a story there."),
  o('o-037', 'strangers', "Is that book any good? I've been looking for something new."),
  o('o-038', 'strangers', "Beautiful day, right? Are you making the most of it or just passing through?"),
  o('o-039', 'strangers', "Your dog is amazing. What's their whole deal?"),
  o('o-040', 'strangers', "First time here? I'm trying to figure out if this place is as good as people say."),

  // group (10)
  o('o-041', 'group', "Question for the group: what's the best thing you've eaten this week?"),
  o('o-042', 'group', "Okay, hot-take round: what's something everyone loves that you don't get?"),
  o('o-043', 'group', "If we all had to team up for a trivia night, what's everyone's category?"),
  o('o-044', 'group', 'Whose phone wallpaper has the best story? Everyone show.'),
  o('o-045', 'group', "What's the group's collective opinion on [current thing]? I need a ruling."),
  o('o-046', 'group', 'If this group started a business together, what would it be and who does what?'),
  o('o-047', 'group', "What's everyone's most useless talent? I'll go first."),
  o('o-048', 'group', "Two truths and a lie, speed round. Who's in?"),
  o('o-049', 'group', "Where should we all actually go for the next hangout? Dream big."),
  o('o-050', 'group', 'What was everyone doing exactly ten years ago?'),

  // online-date (10)
  o('o-051', 'online-date', 'Your photo from [place] — what was the story behind that trip?'),
  o('o-052', 'online-date', "Important first question: what's your go-to comfort food?"),
  o('o-053', 'online-date', "Your profile says you're into [thing] — how did you get into that?"),
  o('o-054', 'online-date', "What's the best thing that happened to you this week? I'll trade you mine."),
  o('o-055', 'online-date', "Coffee, cocktails, or a walk somewhere interesting — what's your ideal first meet?"),
  o('o-056', 'online-date', "What's something you're low-key an expert in?"),
  o('o-057', 'online-date', "Two options: tell me your most-used emoji, or your most controversial food opinion."),
  o('o-058', 'online-date', "What does a really good weekend look like for you?"),
  o('o-059', 'online-date', "If we skipped the small talk: what's something you're excited about right now?"),
  o('o-060', 'online-date', "What's the last thing that made you laugh way too hard?"),
]
