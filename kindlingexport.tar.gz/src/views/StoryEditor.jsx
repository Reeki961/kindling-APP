import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import RecordingList from '../components/RecordingList.jsx'

// Step 1: write the story out fully. Autosaves on every keystroke
// (the reducer + debounced localStorage write handle persistence).
export default function StoryEditor({ story, onUpdate, onNext, onDelete }) {
  const { dispatch } = useApp()
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [triggerDraft, setTriggerDraft] = useState('')

  const triggers = story.triggers ?? []

  const addTrigger = () => {
    const t = triggerDraft.trim().toLowerCase()
    if (!t || triggers.includes(t)) {
      setTriggerDraft('')
      return
    }
    onUpdate({ triggers: [...triggers, t] })
    setTriggerDraft('')
  }

  return (
    <>
      <h1 className="view-title">Write it out</h1>
      <p className="view-sub">
        Every detail, no filter — like you're texting it to a friend. You'll trim it down in the next step.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <input
          value={story.title}
          placeholder="Title (e.g. The wedding cake disaster)"
          onChange={(e) => onUpdate({ title: e.target.value })}
        />
        <textarea
          className="story-textarea"
          value={story.fullText}
          placeholder="So there I was…"
          onChange={(e) => onUpdate({ fullText: e.target.value })}
        />

        {/* Triggers are the doorway topics from the segues guide — the index you
            check in real time instead of searching your whole life for a story. */}
        <div>
          <h2 className="section-h" style={{ marginTop: 4 }}>Triggers</h2>
          <p className="settings-note" style={{ marginTop: 0, marginBottom: 10 }}>
            Topics that open a door to this story. When one comes up in conversation, you'll know you have something.
          </p>
          <div className="chips" style={{ paddingBottom: 10 }}>
            {triggers.map((t) => (
              <button
                key={t}
                className="chip active"
                onClick={() => onUpdate({ triggers: triggers.filter((x) => x !== t) })}
              >
                {t} ✕
              </button>
            ))}
            {triggers.length === 0 && <span className="settings-note">None yet</span>}
          </div>
          <div className="sheet-row">
            <input
              value={triggerDraft}
              placeholder="weddings, driving, disasters…"
              onChange={(e) => setTriggerDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  addTrigger()
                }
              }}
            />
            <button className="btn btn-ghost" style={{ flex: '0 0 auto' }} onClick={addTrigger} disabled={!triggerDraft.trim()}>
              Add
            </button>
          </div>
        </div>

        {(story.recordings ?? []).length > 0 && (
          <div>
            <h2 className="section-h" style={{ marginTop: 4 }}>Recordings</h2>
            <RecordingList
              recordings={story.recordings}
              onDelete={(id) => dispatch({ type: 'DELETE_RECORDING', storyId: story.id, recordingId: id })}
            />
          </div>
        )}

        <button className="btn btn-primary" onClick={onNext} disabled={!story.fullText.trim()}>
          Next: distill into beats ›
        </button>
        <button
          className="btn btn-danger"
          onClick={() => {
            if (confirmDelete) onDelete()
            else setConfirmDelete(true)
          }}
        >
          {confirmDelete ? 'Tap again to delete this story' : 'Delete story'}
        </button>
      </div>
    </>
  )
}
