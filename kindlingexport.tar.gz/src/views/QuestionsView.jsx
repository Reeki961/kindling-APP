import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { QUESTION_CATEGORIES } from '../data/seedQuestions.js'
import SearchBar from '../components/SearchBar.jsx'
import ListItem from '../components/ListItem.jsx'
import EditSheet from '../components/EditSheet.jsx'
import DrawMode from './DrawMode.jsx'

const catLabel = (key) => QUESTION_CATEGORIES.find((c) => c.key === key)?.label ?? key

export default function QuestionsView() {
  const { state, dispatch, deleteItem, markUsed } = useApp()
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState(null)
  const [favOnly, setFavOnly] = useState(false)
  const [provenOnly, setProvenOnly] = useState(false)
  const [drawing, setDrawing] = useState(false)
  const [editing, setEditing] = useState(null) // null | 'new' | question object

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase()
    return state.questions.filter(
      (item) =>
        !item.deleted &&
        (!category || item.category === category) &&
        (!favOnly || item.favorite) &&
        (!provenOnly || (item.usedCount ?? 0) > 0) &&
        (!q || item.text.toLowerCase().includes(q))
    )
  }, [state.questions, search, category, favOnly, provenOnly])

  return (
    <div className="view">
      <h1 className="view-title">Questions</h1>
      <p className="view-sub">Your vault of open-ended questions.</p>

      <button className="draw-btn" onClick={() => setDrawing(true)}>
        🔥 Give me one
      </button>

      <SearchBar value={search} onChange={setSearch} placeholder="Search questions…" />
      <div className="chips">
        <button className={`chip ${favOnly ? 'active' : ''}`} onClick={() => setFavOnly(!favOnly)}>
          ★ Favorites
        </button>
        <button className={`chip ${provenOnly ? 'active' : ''}`} onClick={() => setProvenOnly(!provenOnly)}>
          ✓ Proven
        </button>
        <button
          className={`chip ${category === null && !favOnly && !provenOnly ? 'active' : ''}`}
          onClick={() => { setCategory(null); setFavOnly(false); setProvenOnly(false) }}
        >
          All
        </button>
        {QUESTION_CATEGORIES.map((c) => (
          <button
            key={c.key}
            className={`chip ${category === c.key ? 'active' : ''}`}
            onClick={() => setCategory(category === c.key ? null : c.key)}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="item-list">
        {visible.map((item) => (
          <ListItem
            key={item.id}
            text={item.text}
            subLabel={catLabel(item.category)}
            favorite={item.favorite}
            onToggleFavorite={() => dispatch({ type: 'TOGGLE_FAVORITE_QUESTION', id: item.id })}
            onEdit={() => setEditing(item)}
          />
        ))}
        {visible.length === 0 && (
          <p className="empty-note">Nothing matches. Try clearing the search or filters — or add your own with the + button.</p>
        )}
      </div>

      <button className="fab" onClick={() => setEditing('new')} aria-label="Add question">＋</button>

      {drawing && (
        <DrawMode
          items={visible.length > 0 ? visible : state.questions.filter((i) => !i.deleted)}
          label="Ask this"
          onToggleFavorite={(id) => dispatch({ type: 'TOGGLE_FAVORITE_QUESTION', id })}
          onMarkUsed={(id) => markUsed('question', id)}
          onClose={() => setDrawing(false)}
        />
      )}

      {editing && (
        <EditSheet
          title={editing === 'new' ? 'New question' : 'Edit question'}
          categories={QUESTION_CATEGORIES}
          categoryLabel="Category"
          item={editing === 'new' ? null : editing}
          defaultCategory={category}
          onSave={(text, cat) =>
            editing === 'new'
              ? dispatch({ type: 'ADD_QUESTION', text, category: cat })
              : dispatch({ type: 'EDIT_QUESTION', id: editing.id, text, category: cat })
          }
          onDelete={editing === 'new' ? null : () => deleteItem('question', editing.id, 'Question')}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  )
}
