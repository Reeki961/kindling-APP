export default function SearchBar({ value, onChange, placeholder = 'Search…' }) {
  return (
    <div className="searchbar">
      <input
        type="search"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  )
}
