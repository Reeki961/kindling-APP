const TABS = [
  { key: 'questions', label: 'Questions', icon: '❓' },
  { key: 'openers', label: 'Openers', icon: '💬' },
  { key: 'rescue', label: 'Rescue', icon: '🛟' },
  { key: 'people', label: 'People', icon: '👥' },
  { key: 'stories', label: 'Stories', icon: '📖' },
  { key: 'settings', label: 'Settings', icon: '⚙️' },
]

export default function TabBar({ tab, onChange }) {
  return (
    <nav className="tabbar">
      {TABS.map((t) => (
        <button key={t.key} className={tab === t.key ? 'active' : ''} onClick={() => onChange(t.key)}>
          <span className="tab-icon">{t.icon}</span>
          {t.label}
        </button>
      ))}
    </nav>
  )
}
