export default function TipReader({ tip, onBack }) {
  return (
    <div className="view reader">
      <button className="back-btn" onClick={onBack}>‹ Stories</button>
      <h2>{tip.title}</h2>
      <p className="tagline">{tip.tagline}</p>
      {tip.sections.map((sec, i) => (
        <section key={i}>
          <h3>{sec.heading}</h3>
          {sec.body.map((p, j) => (
            <p key={j}>{p}</p>
          ))}
          {sec.list && (
            <ul>
              {sec.list.map((li, j) => (
                <li key={j}>{li}</li>
              ))}
            </ul>
          )}
        </section>
      ))}
    </div>
  )
}
