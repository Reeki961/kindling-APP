import { useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import Recorder from '../components/Recorder.jsx'
import RecordingList from '../components/RecordingList.jsx'

// Step 3: full-screen cue cards, one beat at a time. Say the story OUT LOUD
// using only the cue; peek at the full text only if stuck. Recording is the point
// where rehearsal becomes feedback — you hear whether it actually landed.
export default function PracticeMode({ story, onDone, onBack, onClose }) {
  const { dispatch, setVeiled } = useApp()
  const beats = story.beats.filter((b) => b.trim())
  const [index, setIndex] = useState(0)
  const [peeking, setPeeking] = useState(false)
  const [justSaved, setJustSaved] = useState(null)

  // Nothing to rehearse — never show a blank card, and never let "Done" credit
  // a practice rep for a story with no beats.
  if (beats.length === 0) {
    return (
      <div className="fullscreen">
        <div className="fullscreen-top">
          <span className="bigcard-label">{story.title || 'Practice'}</span>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="bigcard" onClick={onBack}>
          <div className="bigcard-text">No beats yet.</div>
          <div className="bigcard-hint">Add at least one cue before rehearsing.</div>
        </div>
        <button className="btn btn-primary" onClick={onBack}>
          Write the beats ›
        </button>
      </div>
    )
  }

  const last = index >= beats.length - 1

  const next = () => {
    setPeeking(false)
    if (!last) setIndex(index + 1)
    else onDone()
  }

  const onSaved = (recording) => {
    dispatch({ type: 'ADD_RECORDING', storyId: story.id, recording })
    setJustSaved(recording)
  }

  return (
    <div className="fullscreen">
      <div className="fullscreen-top">
        <button className="icon-btn" onClick={onBack} aria-label="Edit beats">✎</button>
        <span className="bigcard-label">{story.title || 'Practice'}</span>
        <span style={{ display: 'flex', gap: 4 }}>
          <button className="icon-btn" onClick={() => setVeiled(true)} aria-label="Hide screen">🙈</button>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </span>
      </div>

      <div className="bigcard" onClick={next}>
        {peeking ? (
          <div className="story-fulltext" style={{ maxHeight: '55vh' }} onClick={(e) => e.stopPropagation()}>
            {story.fullText}
          </div>
        ) : (
          <>
            <span className="bigcard-label">Beat {index + 1} of {beats.length}</span>
            <div className="bigcard-text">{beats[index]}</div>
            <div className="bigcard-hint">say it out loud, then tap for the next beat</div>
          </>
        )}
      </div>

      <div className="progress-dots">
        {beats.map((_, i) => (
          <span key={i} className={`dot ${i <= index ? 'on' : ''}`} />
        ))}
      </div>

      <div onClick={(e) => e.stopPropagation()}>
        <Recorder onSaved={onSaved} compact />
        {justSaved && (
          <>
            <p className="settings-note" style={{ textAlign: 'center' }}>Saved — listen back:</p>
            <RecordingList
              recordings={[justSaved]}
              onDelete={(id) => {
                dispatch({ type: 'DELETE_RECORDING', storyId: story.id, recordingId: id })
                setJustSaved(null)
              }}
            />
          </>
        )}
      </div>

      <div className="sheet-row" style={{ marginTop: 10 }}>
        <button className="btn btn-ghost" onClick={() => setPeeking(!peeking)}>
          {peeking ? 'Back to beats' : 'Peek at full story'}
        </button>
        <button className="btn btn-primary" onClick={next}>
          {last ? '✓ Done' : 'Next beat ›'}
        </button>
      </div>
    </div>
  )
}
