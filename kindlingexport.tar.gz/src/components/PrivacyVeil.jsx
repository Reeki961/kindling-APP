// Covers the whole screen with something boring. Two jobs:
//   1. one tap to blank the screen when someone leans over
//   2. hides content in the app-switcher snapshot when you leave the app
// Deliberately looks like nothing — no app name, no icon, no hint of content.
export default function PrivacyVeil({ onDismiss }) {
  return (
    <div className="veil" onClick={onDismiss} role="button" aria-label="Tap to show">
      <span className="veil-hint">tap to show</span>
    </div>
  )
}
