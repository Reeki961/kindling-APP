import { useEffect, useRef, useState } from 'react'
import { getRecording, deleteRecording } from '../storage/audio.js'

const fmt = (ms) => {
  const s = Math.round(ms / 1000)
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

const when = (iso) => {
  const d = new Date(iso)
  const today = new Date()
  const sameDay = d.toDateString() === today.toDateString()
  return sameDay
    ? `Today ${d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
    : d.toLocaleDateString([], { month: 'short', day: 'numeric' })
}

function RecordingRow({ rec, onDelete }) {
  const [url, setUrl] = useState(null)
  const [missing, setMissing] = useState(false)
  const [confirm, setConfirm] = useState(false)
  const urlRef = useRef(null)

  useEffect(() => {
    let cancelled = false
    getRecording(rec.id).then((blob) => {
      if (cancelled) return
      if (!blob) {
        setMissing(true)
        return
      }
      const u = URL.createObjectURL(blob)
      urlRef.current = u
      setUrl(u)
    })
    return () => {
      cancelled = true
      if (urlRef.current) URL.revokeObjectURL(urlRef.current)
    }
  }, [rec.id])

  return (
    <div className="item recording-row">
      <div className="item-text">
        {missing ? (
          <span className="settings-note">Audio file missing</span>
        ) : url ? (
          <audio controls src={url} preload="none" />
        ) : (
          <span className="settings-note">Loading…</span>
        )}
        <span className="item-cat">
          {when(rec.createdAt)} · {fmt(rec.durationMs)}
        </span>
      </div>
      <div className="item-actions">
        <button
          className="icon-btn"
          onClick={() => {
            if (confirm) {
              deleteRecording(rec.id).finally(() => onDelete(rec.id))
            } else setConfirm(true)
          }}
          aria-label="Delete recording"
        >
          {confirm ? '✓' : '🗑'}
        </button>
      </div>
    </div>
  )
}

export default function RecordingList({ recordings, onDelete }) {
  if (!recordings || recordings.length === 0) return null
  return (
    <div className="item-list" style={{ marginTop: 10 }}>
      {recordings.map((rec) => (
        <RecordingRow key={rec.id} rec={rec} onDelete={onDelete} />
      ))}
    </div>
  )
}
