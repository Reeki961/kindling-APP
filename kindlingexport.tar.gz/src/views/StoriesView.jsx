import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { tips } from '../data/tips.js'
import { newId } from '../utils/id.js'
import { practiceStats } from '../utils/streak.js'
import SearchBar from '../components/SearchBar.jsx'
import TipReader from './TipReader.jsx'
import StoryWizard from './StoryWizard.jsx'

const DAY_INITIALS = ['S', 'M', 'T', 'W', 'T', 'F', 'S']

function StreakStrip({ stats }) {
  const today = new Date().getDay()
  // days[] is oldest-first over the last 7 calendar days, ending today.
  const labels = Array.from({ length: 7 }, (_, i) => DAY_INITIALS[(today - 6 + i + 7) % 7])

  return (
    <div className="streak">
      <div className="streak-head">
        <span className="streak-count">
          {stats.current > 0 ? `🔥 ${stats.current} day${stats.current === 1 ? '' : 's'}` : 'No streak yet'}
        </span>
        <span className="settings-note" style={{ margin: 0 }}>
          {stats.thisWeek} rehearsal{stats.thisWeek === 1 ? '' : 's'} this week
        </span>
      </div>
      <div className="streak-days">
        {stats.days.map((on, i) => (
          <span key={i} className={`streak-day ${on ? 'on' : ''}`}>
            {labels[i]}
          </span>
        ))}
      </div>
      {stats.longest > 1 && <p className="settings-note">Longest run: {stats.longest} days</p>}
    </div>
  )
}

export default function StoriesView() {
  const { state, dispatch } = useApp()
  const [openTip, setOpenTip] = useState(null)
  const [openStory, setOpenStory] = useState(null) // { id, step }
  const [search, setSearch] = useState('')

  const stats = useMemo(() => practiceStats(state.practiceLog ?? []), [state.practiceLog])

  // Search matches title, story text, and triggers — so "airports" surfaces the
  // story you tagged with it even if the word never appears in the text.
  const visibleStories = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return state.stories
    return state.stories.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.fullText.toLowerCase().includes(q) ||
        (s.triggers ?? []).some((t) => t.includes(q)) ||
        (s.beats ?? []).some((b) => b.toLowerCase().includes(q))
    )
  }, [state.stories, search])

  if (openTip) return <TipReader tip={openTip} onBack={() => setOpenTip(null)} />
  if (openStory) {
    const story = state.stories.find((s) => s.id === openStory.id)
    if (story)
      return <StoryWizard story={story} initialStep={openStory.step} onExit={() => setOpenStory(null)} />
  }

  const newStory = () => {
    const id = newId()
    dispatch({ type: 'CREATE_STORY', id })
    setOpenStory({ id, step: 1 })
  }

  return (
    <div className="view">
      <h1 className="view-title">Stories</h1>
      <p className="view-sub">Write it out first — that's your strength. Then distill and practice out loud.</p>

      <button className="draw-btn" onClick={newStory}>
        ✍️ Start a new story
      </button>

      {state.stories.length > 0 && <StreakStrip stats={stats} />}

      <h2 className="section-h">My stories</h2>
      {state.stories.length > 2 && (
        <SearchBar value={search} onChange={setSearch} placeholder="Search stories or triggers…" />
      )}
      <div className="item-list">
        {visibleStories.map((s) => (
          <div className="item" key={s.id}>
            <button
              className="item-text"
              style={{ textAlign: 'left' }}
              // Route on FILLED beats: BeatDistiller pads the array to 5, so
              // beats.length stays 5 even after the text is cleared out again.
              onClick={() =>
                setOpenStory({
                  id: s.id,
                  step: s.beats.filter((b) => b.trim()).length > 0 ? 3 : s.fullText ? 2 : 1,
                })
              }
            >
              {s.title || 'Untitled story'}
              <span className="item-cat">
                {s.beats.filter(Boolean).length > 0
                  ? `${s.beats.filter(Boolean).length} beats · practiced ${s.practiceCount}×`
                  : s.fullText
                    ? 'written — ready to distill'
                    : 'draft'}
                {(s.recordings ?? []).length > 0 && ` · 🎙 ${s.recordings.length}`}
              </span>
              {(s.triggers ?? []).length > 0 && (
                <span className="trigger-row">
                  {s.triggers.map((t) => (
                    <span className="trigger-tag" key={t}>{t}</span>
                  ))}
                </span>
              )}
            </button>
            <div className="item-actions">
              <button className="icon-btn" onClick={() => setOpenStory({ id: s.id, step: 1 })} aria-label="Edit story">
                ✎
              </button>
            </div>
          </div>
        ))}
        {state.stories.length === 0 && (
          <p className="empty-note">
            No stories yet. Think of something that happened to you — a disaster, a coincidence, a small victory — and
            write it down like you'd text it to a friend.
          </p>
        )}
        {state.stories.length > 0 && visibleStories.length === 0 && (
          <p className="empty-note">No story matches "{search}".</p>
        )}
      </div>

      <h2 className="section-h">Learn the craft</h2>
      <div className="item-list">
        {tips.map((t) => (
          <button className="tip-card" key={t.id} onClick={() => setOpenTip(t)}>
            <h4>{t.title}</h4>
            <p>{t.tagline}</p>
          </button>
        ))}
      </div>
    </div>
  )
}
