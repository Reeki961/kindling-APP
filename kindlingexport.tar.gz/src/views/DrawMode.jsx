import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'

function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// Full-screen one-at-a-time card. `items` = [{id, text, favorite, usedCount}].
// Tap anywhere = next; reshuffles when the deck runs out (no repeats until then).
export default function DrawMode({ items, label, onToggleFavorite, onMarkUsed, onClose }) {
  const { setVeiled } = useApp()
  const [round, setRound] = useState(0)
  const [index, setIndex] = useState(0)
  const [markedThisCard, setMarkedThisCard] = useState(null)
  const deck = useMemo(() => shuffle(items.map((i) => i.id)), [round])

  if (items.length === 0) {
    return (
      <div className="fullscreen">
        <div className="fullscreen-top">
          <span className="bigcard-label">{label}</span>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="bigcard" onClick={onClose}>
          <div className="bigcard-text">Nothing here yet.</div>
          <div className="bigcard-hint">Add some first, then come back.</div>
        </div>
      </div>
    )
  }

  const currentId = deck[index]
  const current = items.find((i) => i.id === currentId) ?? items[0]

  const next = () => {
    setMarkedThisCard(null)
    if (index + 1 >= deck.length) {
      setRound((r) => r + 1)
      setIndex(0)
    } else {
      setIndex(index + 1)
    }
  }

  return (
    <div className="fullscreen">
      <div className="fullscreen-top">
        <span className="bigcard-label">{label}</span>
        <span style={{ display: 'flex', gap: 4 }}>
          <button className="icon-btn" onClick={() => setVeiled(true)} aria-label="Hide screen">🙈</button>
          <button className="icon-btn" onClick={onClose} aria-label="Close">✕</button>
        </span>
      </div>

      <div className="bigcard" onClick={next}>
        <div className="bigcard-text">{current.text}</div>
        <div className="bigcard-hint">tap anywhere for another</div>
      </div>

      <div className="draw-actions" onClick={(e) => e.stopPropagation()}>
        <button
          className={`icon-btn ${current.favorite ? 'fav' : ''}`}
          style={{ fontSize: 26 }}
          onClick={() => onToggleFavorite(current.id)}
          aria-label="Favorite"
        >
          {current.favorite ? '★' : '☆'}
        </button>

        {/* Records that a line actually worked in a real conversation, so
            "Proven" reflects evidence rather than good intentions. */}
        {onMarkUsed && (
          <button
            className={`used-btn ${markedThisCard === current.id ? 'done' : ''}`}
            onClick={() => {
              onMarkUsed(current.id)
              setMarkedThisCard(current.id)
            }}
          >
            {markedThisCard === current.id ? '✓ Logged' : 'I used this'}
            {current.usedCount > 0 && markedThisCard !== current.id && (
              <span className="used-count">{current.usedCount}×</span>
            )}
          </button>
        )}
      </div>
    </div>
  )
}
