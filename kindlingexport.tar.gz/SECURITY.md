# Kindling — security notes

Audit date: 2026-09-07

## The honest threat model

Kindling has **no server, no accounts, and stores no credentials.** Most
web-security advice — SQL injection, CSRF, auth bypass, session hijacking —
simply doesn't apply, because there is no backend and no login to attack.
Everyone's data sits in their own browser and is never transmitted anywhere.

That reshapes the risk. The question isn't "can someone break into the app",
it's "can someone become the app".

### 1. Your Google account — by far the biggest risk

It controls deployment. An attacker who gets it can push malicious JavaScript to
`kindling-ios.web.app`, and that code runs on every installed copy with full
access to that person's stored stories, notes and recordings. Users would have
no warning: the app updates itself silently by design.

Every other defence in this document is secondary to this one.

- Use a **passkey or hardware-backed 2FA**, not SMS (SIM-swap defeats SMS).
- Review devices and third-party app access on the account periodically.
- Treat the recovery email/phone as equally sensitive — they're a way in.

### 2. This laptop

`~/.config/configstore/firebase-tools.json` holds a live deploy token. It is
correctly `600` (owner-only), but anyone who can run commands as your user can
deploy to your site without needing your Google password.

```bash
npx firebase-tools logout      # revoke if the machine is lost or shared
```

### 3. Supply chain

A compromised npm package would ship straight to users. Run `npm audit` before
any deploy, and be sceptical of adding new dependencies — the app deliberately
has only four.

## Audited and clean

| Check | Result |
|---|---|
| Dependency vulnerabilities | **0** (production and build) |
| XSS sinks | none — no `dangerouslySetInnerHTML`, `innerHTML`, `eval`, `new Function`, `document.write` |
| Dynamic `href`/`src` from user data | none (only a browser-generated `blob:` URL for audio) |
| Source maps in production | none |
| Secrets in repo | none — the app uses no Firebase SDK, so there is no API key |
| Source files served publicly | no — Firebase serves `dist/` only; `src/App.jsx` etc. hit the SPA fallback |

### Live response headers

`Content-Security-Policy` · `Strict-Transport-Security` (preload) ·
`X-Content-Type-Options: nosniff` · `X-Frame-Options: DENY` ·
`Referrer-Policy: no-referrer` · `Cross-Origin-Opener-Policy` ·
`Cross-Origin-Resource-Policy` · `Permissions-Policy`

## Decisions and known gaps

**Trusted Types — tested and rejected.** Adding
`require-trusted-types-for 'script'` to the CSP breaks
`navigator.serviceWorker.register()`; the app still renders but the service
worker never registers, silently killing offline mode. Don't enable it without
first wrapping the SW registration in a Trusted Types policy.

**`style-src 'unsafe-inline'`** is the one loose thread in the CSP, required by
~30 `style={{...}}` props. Low risk in practice: `script-src` is locked to
`'self'`, and `img-src`/`connect-src` block the exfiltration paths CSS injection
would need. Moving those styles into CSS classes would let you drop it.

**Data at rest is not encrypted.** Anyone with your unlocked phone, or with
devtools access on your machine, can read the stored stories and notes. The
privacy features (discreet text, the veil) deter shoulder-surfing, not someone
holding the device. Encrypting with a passphrase via Web Crypto is possible but
means permanent data loss if the passphrase is forgotten.

**Screenshots cannot be blocked** by any website.

## Before each deploy

```bash
npm audit && npm run deploy
```

Re-run `firebase init hosting` at your peril — it resets `firebase.json` and
strips every header above.
