import { useEffect, useState } from 'react'

// iOS large-title pattern: each screen shows its big title inline, and once you
// scroll past it a compact translucent bar fades in with the same title centred.
// Scroll events don't bubble, so we listen in the capture phase — that catches
// whichever .view is currently mounted without every view wiring itself up.
export default function NavBar({ title }) {
  const [compact, setCompact] = useState(false)

  useEffect(() => {
    const onScroll = (e) => {
      const el = e.target
      if (!el?.classList?.contains?.('view')) return
      setCompact(el.scrollTop > 44)
    }
    document.addEventListener('scroll', onScroll, true)
    return () => document.removeEventListener('scroll', onScroll, true)
  }, [])

  // Reset when switching screens — the new view starts at the top.
  useEffect(() => setCompact(false), [title])

  return (
    <div className={`navbar ${compact ? 'shown' : ''}`} aria-hidden={!compact}>
      <span className="navbar-title">{title}</span>
    </div>
  )
}
