#!/usr/bin/env python3
"""
Kindling seed helper.

Adds content to the seed files safely and checks them for problems. Runs on your
computer, not in the app — it just edits the .js data files for you.

    python3 tools/seed.py check
    python3 tools/seed.py add questions deeper my-questions.txt
    python3 tools/seed.py add rescues silence -          # read from typing

The point: it handles id numbering and JS string escaping, so you can write
questions with apostrophes and quotes without breaking the file.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "data"

# file, helper-function name, id prefix, name of the grouping field
KINDS = {
    "questions": ("seedQuestions.js", "q", "q", "category"),
    "openers": ("seedOpeners.js", "o", "o", "situation"),
    "rescues": ("seedRescues.js", "r", "r", "situation"),
}

# matches:  q('q-042', 'deeper', "text"),
ENTRY = re.compile(
    r"""^\s*[qor]\(\s*['"](?P<id>[^'"]+)['"]\s*,\s*['"](?P<group>[^'"]+)['"]\s*,\s*(?P<quote>['"])(?P<text>.*)(?P=quote)\s*\)\s*,?\s*$"""
)


def js_string(text):
    """Quote a string for JS. Double quotes + escaping means apostrophes are safe."""
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def read_entries(path):
    entries = []
    for lineno, line in enumerate(path.read_text().splitlines(), 1):
        m = ENTRY.match(line)
        if m:
            entries.append(
                {"id": m["id"], "group": m["group"], "text": m["text"], "line": lineno}
            )
    return entries


def read_groups(path, field):
    """Pull the valid category/situation keys out of the exported list."""
    text = path.read_text()
    block = re.search(r"export const [A-Z_]+ = \[(.*?)\]", text, re.S)
    return re.findall(r"key:\s*'([^']+)'", block.group(1)) if block else []


def next_id(entries, prefix):
    nums = [int(n) for e in entries for n in re.findall(rf"^{prefix}-(\d+)$", e["id"])]
    return (max(nums) + 1) if nums else 1


def cmd_check():
    problems = 0
    for kind, (fname, _, prefix, field) in KINDS.items():
        path = SRC / fname
        entries = read_entries(path)
        groups = set(read_groups(path, field))

        print(f"\n{kind}: {len(entries)} entries, {len(groups)} {field}s")

        seen_ids, seen_text = {}, {}
        for e in entries:
            if e["id"] in seen_ids:
                print(f"  ✗ duplicate id {e['id']} (lines {seen_ids[e['id']]}, {e['line']})")
                problems += 1
            seen_ids[e["id"]] = e["line"]

            key = e["text"].strip().lower()
            if key in seen_text:
                print(f"  ✗ duplicate text on lines {seen_text[key]} and {e['line']}")
                print(f"      {e['text'][:60]}")
                problems += 1
            seen_text[key] = e["line"]

            if e["group"] not in groups:
                print(f"  ✗ line {e['line']}: unknown {field} '{e['group']}'")
                problems += 1

        # empty categories are usually a typo, not a choice
        for g in sorted(groups):
            n = sum(1 for e in entries if e["group"] == g)
            if n == 0:
                print(f"  ! {field} '{g}' has no entries")

    print()
    if problems:
        print(f"✗ {problems} problem(s) found")
        return 1
    print("✓ all seed files look healthy")
    return 0


def cmd_add(kind, group, source):
    if kind not in KINDS:
        print(f"Unknown kind '{kind}'. Use one of: {', '.join(KINDS)}")
        return 1

    fname, fn, prefix, field = KINDS[kind]
    path = SRC / fname
    entries = read_entries(path)
    groups = read_groups(path, field)

    if group not in groups:
        print(f"Unknown {field} '{group}'. Valid options:\n  " + "\n  ".join(groups))
        return 1

    if source == "-":
        print("Type one per line. Blank line or Ctrl-D when done:")
        lines = []
        for line in sys.stdin:
            if not line.strip():
                break
            lines.append(line.strip())
    else:
        lines = [l.strip() for l in Path(source).read_text().splitlines() if l.strip()]

    if not lines:
        print("Nothing to add.")
        return 0

    existing = {e["text"].strip().lower() for e in entries}
    new, skipped = [], []
    for text in lines:
        (skipped if text.lower() in existing else new).append(text)
        existing.add(text.lower())

    for text in skipped:
        print(f"  skipped (already there): {text[:60]}")

    if not new:
        print("Everything was already in there.")
        return 0

    n = next_id(entries, prefix)
    rendered = [
        f"  {fn}('{prefix}-{n + i:03d}', '{group}', {js_string(t)}),"
        for i, t in enumerate(new)
    ]

    # insert before the final closing bracket of the exported array
    src = path.read_text()
    idx = src.rstrip().rfind("]")
    updated = src[:idx].rstrip() + "\n" + "\n".join(rendered) + "\n" + src[idx:]
    path.write_text(updated)

    print(f"\n✓ added {len(new)} to {fname} as {prefix}-{n:03d}…{prefix}-{n + len(new) - 1:03d}")
    print("\n⚠  Now bump SEED_VERSION in src/storage/store.js, or these will NOT")
    print("   appear on your phone. Then: npm run deploy")
    return 0


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if args[0] == "check":
        return cmd_check()
    if args[0] == "add":
        if len(args) != 4:
            print("Usage: python3 tools/seed.py add <questions|openers|rescues> <group> <file|->")
            return 1
        return cmd_add(args[1], args[2], args[3])
    print(f"Unknown command '{args[0]}'. Try: check, add")
    return 1


if __name__ == "__main__":
    sys.exit(main())
