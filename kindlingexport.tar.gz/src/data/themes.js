// Background colour moods. `rainbow` continuously cycles hue; the rest are fixed palettes.
export const THEMES = [
  { key: 'rainbow', label: 'Rainbow', swatch: 'linear-gradient(135deg,#ff5f6d,#ffc371,#7ee8fa,#a06bff)' },
  { key: 'ember', label: 'Ember', swatch: 'linear-gradient(135deg,#ff8a2b,#ff5670)' },
  { key: 'ocean', label: 'Ocean', swatch: 'linear-gradient(135deg,#38bec9,#4a7dff)' },
  { key: 'violet', label: 'Violet', swatch: 'linear-gradient(135deg,#b45cff,#ff6ec7)' },
  { key: 'forest', label: 'Forest', swatch: 'linear-gradient(135deg,#4ade80,#0ea5a4)' },
  { key: 'calm', label: 'Calm', swatch: 'linear-gradient(135deg,#8b8f9a,#5a6472)' },
]

export const DEFAULT_THEME = 'rainbow'
