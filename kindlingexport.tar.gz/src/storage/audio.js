// Voice recordings live in IndexedDB, not localStorage — audio blobs would blow
// the ~5MB string quota instantly. The main document only stores metadata; the
// blob itself is keyed here by recording id.
const DB_NAME = 'kindling-audio'
const DB_VERSION = 1
const STORE = 'recordings'

let dbPromise = null

function openDB() {
  if (dbPromise) return dbPromise
  dbPromise = new Promise((resolve, reject) => {
    let req
    try {
      req = indexedDB.open(DB_NAME, DB_VERSION)
    } catch (e) {
      reject(e)
      return
    }
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE)
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  }).catch((e) => {
    dbPromise = null // let a later call retry (private mode, quota, etc.)
    throw e
  })
  return dbPromise
}

function tx(mode, fn) {
  return openDB().then(
    (db) =>
      new Promise((resolve, reject) => {
        const t = db.transaction(STORE, mode)
        const store = t.objectStore(STORE)
        const req = fn(store)
        t.oncomplete = () => resolve(req?.result)
        t.onerror = () => reject(t.error)
        t.onabort = () => reject(t.error)
      })
  )
}

export function isAudioSupported() {
  return typeof indexedDB !== 'undefined' && typeof MediaRecorder !== 'undefined'
}

export async function putRecording(id, blob) {
  try {
    await tx('readwrite', (s) => s.put(blob, id))
    return true
  } catch {
    return false
  }
}

export async function getRecording(id) {
  try {
    return (await tx('readonly', (s) => s.get(id))) ?? null
  } catch {
    return null
  }
}

export async function deleteRecording(id) {
  try {
    await tx('readwrite', (s) => s.delete(id))
    return true
  } catch {
    return false
  }
}

export async function listRecordingIds() {
  try {
    return (await tx('readonly', (s) => s.getAllKeys())) ?? []
  } catch {
    return []
  }
}

// Drop blobs whose metadata no longer exists — keeps deleted stories from
// leaving orphaned audio behind forever.
export async function pruneOrphans(keepIds) {
  const keep = new Set(keepIds)
  const all = await listRecordingIds()
  const orphans = all.filter((id) => !keep.has(id))
  await Promise.all(orphans.map((id) => deleteRecording(id)))
  return orphans.length
}

export async function audioUsage() {
  try {
    const ids = await listRecordingIds()
    let bytes = 0
    for (const id of ids) {
      const blob = await getRecording(id)
      if (blob) bytes += blob.size
    }
    return { count: ids.length, bytes }
  } catch {
    return { count: 0, bytes: 0 }
  }
}
