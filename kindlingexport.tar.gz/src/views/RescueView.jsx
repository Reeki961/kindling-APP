import { useMemo, useState } from 'react'
import { useApp } from '../context/AppContext.jsx'
import { RESCUE_SITUATIONS } from '../data/seedRescues.js'
import ChipFilter from '../components/ChipFilter.jsx'
import ListItem from '../components/ListItem.jsx'
import EditSheet from '../components/EditSheet.jsx'
import DrawMode from './DrawMode.jsx'

const sitLabel = (key) => RESCUE_SITUATIONS.find((s) => s.key === key)?.label ?? key

export default function RescueView() {
  const { state, dispatch, deleteItem, markUsed } = useApp()
  const [situation, setSituation] = useState(null)
  const [drawing, setDrawing] = useState(false)
  const [editing, setEditing] = useState(null)

  const visible = useMemo(
    () => state.rescues.filter((x) => !x.deleted && (!situation || x.situation === situation)),
    [state.rescues, situation]
  )

  return (
    <div className="view">
      <h1 className="view-title">Rescue</h1>
      <p className="view-sub">
        Lines to use word-for-word when a conversation stalls, a story flops, or you need to get out.
      </p>

      <button className="draw-btn panic" onClick={() => setDrawing(true)}>
        🛟 Give me something to say
      </button>

      <ChipFilter options={RESCUE_SITUATIONS} value={situation} onChange={setSituation} />

      <div className="item-list">
        {visible.map((item) => (
          <ListItem
            key={item.id}
            text={item.text}
            subLabel={sitLabel(item.situation)}
            favorite={item.favorite}
            onToggleFavorite={() => dispatch({ type: 'TOGGLE_FAVORITE_RESCUE', id: item.id })}
            onEdit={() => setEditing(item)}
          />
        ))}
        {visible.length === 0 && <p className="empty-note">Nothing here yet — add your own with the + button.</p>}
      </div>

      <button className="fab" onClick={() => setEditing('new')} aria-label="Add rescue line">＋</button>

      {drawing && (
        <DrawMode
          items={visible}
          label={situation ? sitLabel(situation) : 'Say this'}
          onToggleFavorite={(id) => dispatch({ type: 'TOGGLE_FAVORITE_RESCUE', id })}
          onMarkUsed={(id) => markUsed('rescue', id)}
          onClose={() => setDrawing(false)}
        />
      )}

      {editing && (
        <EditSheet
          title={editing === 'new' ? 'New rescue line' : 'Edit rescue line'}
          categories={RESCUE_SITUATIONS}
          categoryLabel="When to use it"
          item={editing === 'new' ? null : editing}
          defaultCategory={situation}
          onSave={(text, sit) =>
            editing === 'new'
              ? dispatch({ type: 'ADD_RESCUE', text, situation: sit })
              : dispatch({ type: 'EDIT_RESCUE', id: editing.id, text, situation: sit })
          }
          onDelete={editing === 'new' ? null : () => deleteItem('rescue', editing.id, 'Rescue line')}
          onClose={() => setEditing(null)}
        />
      )}
    </div>
  )
}
